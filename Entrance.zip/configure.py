MSVS_VERSION = "12.0"
NUGET_SOURCE = "http://nuget-auto.tenaris.techint.net"
