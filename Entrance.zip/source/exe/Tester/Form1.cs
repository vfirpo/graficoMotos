﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Tenaris.Library.Log;
using Trace = Tenaris.Library.Log.Trace;

namespace Tester
{
    [Trace]
    public partial class Form1 : Form
    {
        private int counter = 0;

        //[Test]
        public Form1()
        {
            InitializeComponent();
            //   Trace.Debug("START");
        }

        //   [Trace]
        private void button1_Click(object sender, EventArgs e)
        {
            //         Trace.Debug("click at {0}", DateTime.Now);
            Trace.Debug("click at {0} áéíóú - AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", DateTime.Now);
            figa(1);
        }

        //   [Trace]
        void figa(int n)
        {
            Trace.Debug("figa");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                throw new Exception("MESSAGGIO ECCEZIONE");
            }
            catch (Exception E)
            {
                Trace.Exception(E, "MESSAGGIO CATCH ORA: {0}", DateTime.Now);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        [Trace(FullExceptionStack = true)]
        void a()
        {
            b();
        }

        //[Trace(FullExceptionStack = true)]
        void b()
        {
            throw new InvalidOperationException();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                a();
            }
            catch (Exception)
            {
                Trace.Error("a() exception!");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Trace.Debug("click at {0} - {1} AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", DateTime.Now, counter++);
            Trace.Debug("click at {0} - {1} AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", DateTime.Now, counter++);
            Trace.Debug("click at {0} - {1} AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", DateTime.Now, counter++);
            Trace.Debug("click at {0} - {1} AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", DateTime.Now, counter++);
            Trace.Debug("click at {0} - {1} AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", DateTime.Now, counter++);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Stopwatch a = Stopwatch.StartNew();
            for (int i=0;i<10;i++) CalcFibonacci(0, 1, 1, 10);
            a.Stop();
            MessageBox.Show(a.ElapsedMilliseconds.ToString());
        }

        private static void CalcFibonacci(int a, int b, int counter, int len)
        {
            if (counter <= len)
            {
                CalcFibonacci(b, a + b, counter + 1, len);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            throw new OutOfMemoryException();
        }
    }
}
