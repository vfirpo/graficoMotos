﻿// -----------------------------------------------------------------------
// <copyright file="FigaAttribute.cs" company="">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace Tenaris.Library.Log
{
   using System;
   using System.Collections.Generic;
   using System.Diagnostics;
   using System.Linq;
   using System.Reflection;
   using System.Text;

   using PostSharp;
   using PostSharp.Aspects;

   /// <summary>
   /// TODO: Update summary.
   /// </summary>
   [Serializable]
   public class TestAttribute : OnMethodBoundaryAspect
   {
      public override void OnEntry(MethodExecutionArgs args)
      {
         base.OnEntry(args);
      }
   }
}
