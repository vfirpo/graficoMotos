﻿// -----------------------------------------------------------------------
// <copyright file="AdditionalLogDestination.cs" company="">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace Tenaris.Library.Log
{
    using System;

    /// <summary>
    /// Additional Log Destinations besides the standard text log file.
    /// </summary>
    [Flags]
    public enum AdditionalLogDestination
    {
        /// <summary>
        /// No additional destination log
        /// </summary>
        None = 0,

        /// <summary>
        /// Log to console
        /// </summary>
        Console = 1,
    }
}
