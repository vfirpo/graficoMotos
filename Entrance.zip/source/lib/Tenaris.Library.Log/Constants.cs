﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Constants.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the Constants type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Log/Constants.cs $
// $Id: Constants.cs 32392 2010-06-27 03:47:42Z apre2k\15827 $

namespace Tenaris.Library.Log
{
    /// <summary>
    /// Internal Log constants
    /// </summary>
    internal static class Constants
    {
        internal const string FileDateFormat = "yyyy'-'MM'-'dd'T'HH'.'mm'.'ss";

        internal const char EnterChar = '>';

        internal const char LeaveChar = '<';

        internal const char InfoChar = '-';

        internal const char WarnChar = '!';

        internal const char ErrorChar = '@';

        internal const string StackTraceBegin =
          "\r\n################################################\r\n" +
            "#   BEGIN OF STACK TRACE                       #\r\n" +
            "################################################\r\n";

        internal const string StackTraceEnd =
          "\r\n################################################\r\n" +
            "#   END OF STACK TRACE                         #\r\n" +
            "################################################";

        internal const string TraceFileBegin =
          "\r\n****************************************************\r\n" +
            "** New log start at: {0}                            \r\n" +
            "****************************************************";

        internal const string ExceptionFormat = "An exception with message \"{0}\" was detected. Stack trace follows.";

        internal const string ExceptionFormatNoStack = "An exception with message \"{0}\" was detected. Stack trace skipped.";
    }
}
