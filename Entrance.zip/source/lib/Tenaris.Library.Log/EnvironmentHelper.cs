﻿using System;
using System.Text;

namespace Tenaris.Library.Log
{
    public class EnvironmentHelper
    {
        public static string ExpandEnvironmentVariables(string text)
        {
            //get only variables from machine not from process.
            string expendedText = Environment.ExpandEnvironmentVariables(text);

            string[] strArray = expendedText.Split('%');

            StringBuilder output = new StringBuilder();
            for (int i = 0; i < strArray.Length - 1; i++)
            {
                if (strArray[i].Length > 0)
                {
                    string part = Environment.GetEnvironmentVariable("%" + strArray[i] + "%", EnvironmentVariableTarget.Process);
                    output.Append(part ?? strArray[i]);
                }
            }

            if (strArray.Length > 0)
                output.Append(strArray[strArray.Length - 1]);

            return output.ToString();
        }
    }
}
