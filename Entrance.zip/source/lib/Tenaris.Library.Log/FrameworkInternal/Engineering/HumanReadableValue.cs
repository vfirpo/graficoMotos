﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="HumanReadableValue.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the HumanReadableValue type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: $
// $Id: $

using System;
using System.Collections.Generic;
using System.Linq;

namespace Tenaris.Library.Log.Engineering
{
    /// <summary>
    ///     Converts from or to human readable values.
    ///     Using a dictionary of unit name and divisor, this class
    ///     calculates a human friendly value, unit pair (or vice-versa).
    /// </summary>
    internal class HumanReadableValue
    {
        /// <summary>
        ///     Initialize a new instance of HumanReadableValue
        /// </summary>
        /// <param name="unitDictionary">The dictionary with the definition of units.</param>
        public HumanReadableValue(Dictionary<string, int> unitDictionary)
        {
            UnitDictionary = unitDictionary;
        }

        /// <summary>
        ///     Unit dictionary
        /// </summary>
        protected Dictionary<string, int> UnitDictionary { get; set; }

        /// <summary>
        ///     Converts a value in a given unit to a human friendly format. If unit is null
        ///     then the BaseUnit is used as default.
        /// </summary>
        /// <param name="value">The value to convert.</param>
        /// <param name="sourceUnit">The units of the given value.</param>
        /// <returns></returns>
        public ValueUnitPair ToHumanReadable(double value, string sourceUnit = null)
        {
            if (double.IsNaN(value))
            {
                return new ValueUnitPair(double.NaN, sourceUnit ?? UnitDictionary.First().Key);
            }

            var result = value;

            if (!string.IsNullOrEmpty(sourceUnit))
            {
                CheckUnit(sourceUnit);
                return ToHumanReadable(FromHumanReadable(new ValueUnitPair(value, sourceUnit)));
            }

            foreach (var item in UnitDictionary)
            {
                if (result >= item.Value)
                {
                    result /= item.Value;
                    if (UnitDictionary.Keys.Last() == item.Key)
                    {
                        sourceUnit = item.Key;
                    }
                }
                else
                {
                    sourceUnit = item.Key;
                    break;
                }
            }

            return new ValueUnitPair(result, sourceUnit);
        }

        /// <summary>
        ///     Given a human friendly value, it returns the value in the BaseUnit units.
        /// </summary>
        /// <param name="value">The value to convert.</param>
        /// <param name="targetUnit">The target unit, if null the BaseUnit is used.</param>
        /// <returns></returns>
        public double FromHumanReadable(ValueUnitPair value, string targetUnit = null)
        {
            CheckUnit(value.Unit);

            var result = value.Value;

            foreach (var item in UnitDictionary)
            {
                if (value.Unit == item.Key)
                {
                    break;
                }
                result *= item.Value;
            }

            if (!string.IsNullOrEmpty(targetUnit))
            {
                CheckUnit(targetUnit);
                foreach (var item in UnitDictionary)
                {
                    if (value.Unit == targetUnit)
                    {
                        break;
                    }
                    result /= item.Value;
                }
            }

            return result;
        }

        private void CheckUnit(string unit)
        {
            if (!UnitDictionary.ContainsKey(unit))
            {
                throw new ArgumentOutOfRangeException("unit", "The specified unit is not defined in the dictionary.");
            }
        }
    }
}