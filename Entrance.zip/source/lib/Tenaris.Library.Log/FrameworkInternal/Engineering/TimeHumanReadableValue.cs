﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="TimeHumanReadableValue.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the ByteHumanReadableValue type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: $
// $Id: $

using System.Collections.Generic;

namespace Tenaris.Library.Log.Engineering
{
    /// <summary>
    ///     Converts time units to a human readable form (that is, for instance,
    ///     converts 120s to 2Min.
    /// </summary>
    internal class TimeHumanReadableValue : HumanReadableValue
    {
        private const int SecondsInMinute = 60;
        private const int MinutesInHour = 60;
        private const int HoursInDay = 24;
        private const int WeeksInYear = 52;

        /// <summary>
        ///     Instantiates a new class
        /// </summary>
        public TimeHumanReadableValue()
            : base(null)
        {
            UnitDictionary = new Dictionary<string, int>
            {
                {@"uS", 1000},
                {@"mS", 1000},
                {@"S", SecondsInMinute},
                {@"Min", MinutesInHour},
                {@"Hr", HoursInDay},
                {@"Day", 7},
                {@"Week", WeeksInYear},
                {@"Year", int.MaxValue}
            };
        }
    }
}