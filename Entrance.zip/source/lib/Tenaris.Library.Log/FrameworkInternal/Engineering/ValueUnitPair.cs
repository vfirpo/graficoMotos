﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ValueUnitPair.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the ValueUnitPair type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: $
// $Id: $

namespace Tenaris.Library.Log.Engineering
{
    /// <summary>
    ///     Represents a value with its unit.
    /// </summary>
    internal struct ValueUnitPair
    {
        private readonly string unit;
        private readonly double value;

        /// <summary>
        ///     Initialize a new ValueUnitPair.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="unit">The unit of measure.</param>
        public ValueUnitPair(double value, string unit)
        {
            this.unit = unit;
            this.value = value;
        }

        /// <summary>
        ///     The value (expreseds in the given units)
        /// </summary>
        public double Value
        {
            get { return value; }
        }

        /// <summary>
        ///     The units of this value.
        /// </summary>
        public string Unit
        {
            get { return unit; }
        }

        /// <summary>
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return string.Format(@"{0}{1}", Value, Unit);
        }
    }
}