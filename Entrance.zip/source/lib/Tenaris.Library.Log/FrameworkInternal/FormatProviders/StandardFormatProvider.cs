﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="StandardFormatProvider.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Named formatter StandardFormatProvider methods.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/trunk/source/sharedlib/System/Text/StringExtensions.cs $
// $Id: StringExtensions.cs 31276 2010-04-16 21:07:12Z apre2k\t61248 $

using System;
using Tenaris.Library.Log.Framework;
using Tenaris.Library.Log.Utility.Conversion;

namespace Tenaris.Library.Log.FormatProviders
{
    /// <summary>
    ///     Provides standard formatters for strings and special objects.
    /// </summary>
    internal class StandardFormatProvider : Singleton<StandardFormatProvider>, IFormatProvider, ICustomFormatter
    {
        private StandardFormatProvider()
        {
        }

        /// <summary>
        /// </summary>
        /// <param name="format"></param>
        /// <param name="arg"></param>
        /// <param name="formatProvider"></param>
        /// <returns></returns>
        public string Format(string format, object arg, IFormatProvider formatProvider)
        {
            if (arg == null)
            {
                return string.Empty;
            }

            var result = string.Empty;

            if (format != null)
            {
                if (arg is string)
                {
                    result = FormatString(format, arg);
                }
                else if (arg is IFormattable)
                {
                    result = ((IFormattable) arg).ToString(format, formatProvider);
                }
                else
                {
                    result = string.Empty;
                }
            }
            else
            {
                result = arg.ToString();
            }

            return result;
        }

        /// <summary>
        /// </summary>
        /// <param name="formatType"></param>
        /// <returns></returns>
        public object GetFormat(Type formatType)
        {
            return typeof(ICustomFormatter).Equals(formatType) ? this : null;
        }

        private static string FormatString(string format, object arg)
        {
            var result = arg.ToString();
            var preceed = false;

            if (format.StartsWith(@"s"))
            {
                format = format.Remove(0, 1);

                if (format.StartsWith(@"-"))
                {
                    preceed = true;
                    format = format.Remove(0, 1);
                }

                var length = format.ToInteger(-1);
                if (length >= 3)
                {
                    if (result.Length > length)
                    {
                        var count = length - 3;
                        var startIndex = preceed ? result.Length - count : 0;
                        result = result.Substring(startIndex, count);
                        result = preceed ? @"..." + result : result + @"...";
                    }
                }
            }
            return result;
        }
    }
}