﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CrossDomainHelpers.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the CrossDomainHelpers type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Framework/CrossDomainHelpers.cs $
//  $Id: CrossDomainHelpers.cs 53966 2011-08-09 21:48:19Z apre2k\t61248 $

using System;
using System.Reflection;
using Tenaris.Library.Log.Utility.AppDomain;

namespace Tenaris.Library.Log.Framework
{
    using System.Security;

    /// <summary>
    ///     Cross domain helper functions
    /// </summary>
    [SecurityCritical]
    internal static class CrossDomainHelpers
    {
        /// <summary>
        ///     Creates a new instance of a singleton class
        /// </summary>
        /// <typeparam name="TSingletonClass"></typeparam>
        /// <param name="host"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static TSingletonClass CreateInstance<TSingletonClass>(this AppDomain host, Type type)
            where TSingletonClass : MarshalByRefObject
        {
            if (host == null)
            {
                throw new ArgumentNullException("host");
            }

            if (type == null)
            {
                throw new ArgumentNullException("type");
            }

            if (string.IsNullOrEmpty(type.FullName))
            {
                throw new InvalidTypeException(string.Format("Type {0} cannot be used since its assembly is null",
                    type.Name));
            }

            var instance = host.FindInstance<TSingletonClass>(type);

            // If there's no active instance -> create one in the specified AppDomain and return (a proxy to) it.
            if (instance == null)
            {
                instance = (TSingletonClass) host.CreateInstanceAndUnwrap(type.Assembly.FullName, type.FullName, false,
                    BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Public,
                    null, null, null, null);

                // Record the fact that now there is an active instance
                host.SetData(type.GUID.ToString(), instance);
            }

            return instance;
        }

        /// <summary>
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static AppDomain GetHost(this Type type)
        {
            var attr = AppDomainNameAttribute.GetInstance(type);

            AppDomain parent;
            if (!attr.UseDefaultDomain)
            {
                parent = FindCurrent(type) ?? AppDomain.CurrentDomain;
            }
            else
            {
                parent = Tool.GetDefault();
            }

            // Get or create the needed AppDomain, or use the parent one if that's what being told
            return !string.IsNullOrEmpty(attr.AppDomainName) ? Tool.GetDomain(attr.AppDomainName, parent) : parent;
        }

        /// <summary>
        /// </summary>
        /// <typeparam name="TSingletonClass"></typeparam>
        /// <param name="host"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static TSingletonClass FindInstance<TSingletonClass>(this AppDomain host, Type type)
            where TSingletonClass : MarshalByRefObject
        {
            return (TSingletonClass) host.GetData(type.GUID.ToString());
        }

        private static AppDomain FindCurrent(Type type)
        {
            return Tool.Find(d => d.GetData(type.GUID.ToString()) != null);
        }
    }
}