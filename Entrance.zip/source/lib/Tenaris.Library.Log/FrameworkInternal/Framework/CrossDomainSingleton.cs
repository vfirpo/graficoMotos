﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CrossDomainSingleton.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the ProcessSingleton type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Framework/CrossDomainSingleton.cs $
// $Id: CrossDomainSingleton.cs 53966 2011-08-09 21:48:19Z apre2k\t61248 $

using System;
using System.Threading;
using Tenaris.Library.Log.Utility.AppDomain;

namespace Tenaris.Library.Log.Framework
{
    using System.Security;

    /// <summary>
    ///     Helper class to allow definition of singleton instances across AppDomain boundaries
    /// </summary>
    /// <typeparam name="TSingletonClass">The class type which needs to be singleton. T has to inherit from MarshalByRefObject.</typeparam>
    public abstract class CrossDomainSingleton<TSingletonClass> : MarshalByRefObject
        where TSingletonClass : MarshalByRefObject
    {
        private static readonly Mutex Exclusion = new Mutex();

        /// <summary>
        ///     Initializes a new instance of the <see cref="CrossDomainSingleton{TSingletonClass}" /> class.
        /// </summary>
        [SecuritySafeCritical]
        protected CrossDomainSingleton()
        {
            SingletonMaker<TSingletonClass>.Initialize(this);
        }

        /// <summary>
        ///     Gets the single possible instance of the class T
        /// </summary>
        /// <exception cref="InvalidTypeException">
        ///     Raised when the type T comes from an invalid assembly,
        ///     i.e. when Type.Assembly returns null or when the returned assembly has null FullName.
        /// </exception>
        public static TSingletonClass Instance
        {
          [SecuritySafeCritical]
          get
          {
            return GetInstance();
          }
        }

        /// <summary>
        ///     Gets a value indicating whether the given class requires special initialization handling and just calling its
        ///     default constructor it's not enough.
        /// </summary>
        protected static bool RequiresInitialization
        {
            get { return SingletonMaker<TSingletonClass>.RequiresInitialization; }
        }

        /// <summary>
        ///     Overrides the lifetime service initializer so the object is never disposed by GC.
        /// </summary>
        /// <returns>
        ///     Always null.
        /// </returns>
        [SecurityCritical]
        public override object InitializeLifetimeService()
        {
            return null;
        }

        [SecurityCritical]
        private static TSingletonClass GetInstance()
        {
            if (SingletonMaker<TSingletonClass>.IsInitialized)
            {
                return SingletonMaker<TSingletonClass>.Instance;
            }

            Exclusion.WaitOne();
            try
            {
                if (SingletonMaker<TSingletonClass>.IsInitialized)
                {
                    return SingletonMaker<TSingletonClass>.Instance;
                }

                var type = typeof(TSingletonClass);

                var host = type.GetHost();
                var instance = host.CreateInstance<TSingletonClass>(type);

                if (host != AppDomain.CurrentDomain)
                {
                    SingletonMaker<TSingletonClass>.Initialize(instance);
                }

                return instance;
            }
            finally
            {
                Exclusion.ReleaseMutex();
            }
        }
    }
}