﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RemotableSingleton.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the RemotableSingleton type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Framework/RemoteableSingleton.cs $
// $Id: RemoteableSingleton.cs 53966 2011-08-09 21:48:19Z apre2k\t61248 $

using System;

namespace Tenaris.Library.Log.Framework
{
    using System.Security;

    /// <summary>
    ///     Singleton class, only permits the existence of a single instance of the specified type TSingletonClass, allows it
    ///     to be remotable.
    /// </summary>
    /// <typeparam name="TSingletonClass">
    ///     The type of the class to instantiate.
    /// </typeparam>
    internal abstract class RemotableSingleton<TSingletonClass> : MarshalByRefObject
        where TSingletonClass : MarshalByRefObject
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="RemotableSingleton{TSingletonClass}" /> class.
        /// </summary>
        protected RemotableSingleton()
        {
            SingletonMaker<TSingletonClass>.Initialize(this);
        }

        /// <summary>
        ///     Gets the single Instance of this Singleton.
        /// </summary>
        public static TSingletonClass Instance
        {
            get { return SingletonMaker<TSingletonClass>.Instance; }
        }

        /// <summary>
        ///     Gets a value indicating whether the given class requires special initialization handling and just calling its
        ///     default constructor it's not enough.
        /// </summary>
        protected static bool RequiresInitialization
        {
            get { return SingletonMaker<TSingletonClass>.RequiresInitialization; }
        }

        /// <summary>
        ///     Overrides the lifetime service initializer so the object is never dispose by GC.
        /// </summary>
        /// <returns>
        ///     Always null.
        /// </returns>
        [SecurityCritical]
        public override object InitializeLifetimeService()
        {
            return null;
        }

        /// <summary>
        ///     Initializes the singleton with the provided instance <paramref name="value" />.
        /// </summary>
        /// <param name="value">
        ///     The instance to assign as *the* singleton instance.
        /// </param>
        protected static void Initialize(TSingletonClass value)
        {
            SingletonMaker<TSingletonClass>.Initialize(value);
        }
    }
}