﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RequiresInitializationAttribute.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the RequiresInitializationAttribute type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Framework/RequiresInitializationAttribute.cs $
//  $Id: RequiresInitializationAttribute.cs 51459 2011-04-20 18:21:43Z apre2k\t61248 $

using System;
using System.Reflection;

namespace Tenaris.Library.Log.Framework
{
    /// <summary>
    ///     An attribute used as a indication that an static class singleton requires initialization code to be executed
    ///     prior to it being available to the outside world.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class)]
    internal sealed class RequiresInitializationAttribute : Attribute
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="RequiresInitializationAttribute" /> class.
        /// </summary>
        public RequiresInitializationAttribute()
        {
            FailOnDefaultCreationAttempt = true;
        }

        /// <summary>
        ///     Gets or sets a value indicating whether an exception should be raised when the singleton is accessed and it wasn't
        ///     initialized yet (default = true).
        /// </summary>
        public bool FailOnDefaultCreationAttempt { get; set; }

        /// <summary>
        ///     Tries to obtain the single instance of this attribute in the given type.
        /// </summary>
        /// <param name="element">
        ///     The element on which the attribute is being checked.
        /// </param>
        /// <returns>
        ///     The attribute instance, if present, or null when not.
        /// </returns>
        public static RequiresInitializationAttribute GetInstance(MemberInfo element)
        {
            return
                (RequiresInitializationAttribute)
                    GetCustomAttribute(element, typeof(RequiresInitializationAttribute), true);
        }
    }
}