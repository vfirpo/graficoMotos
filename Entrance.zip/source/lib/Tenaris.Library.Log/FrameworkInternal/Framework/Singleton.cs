﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Singleton.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the Singleton type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Framework/Singleton.cs $
// $Id: Singleton.cs 51459 2011-04-20 18:21:43Z apre2k\t61248 $

namespace Tenaris.Library.Log.Framework
{
    /// <summary>
    ///     Singleton class, only permits the existance of a single instance of the specified type
    ///     <typeparamref name="TSingletonClass" />/>
    /// </summary>
    /// <typeparam name="TSingletonClass">
    ///     The type of the class to instantiate
    /// </typeparam>
    internal abstract class Singleton<TSingletonClass>
        where TSingletonClass : class
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="Singleton{TSingletonClass}" /> class.
        /// </summary>
        protected Singleton()
        {
            SingletonMaker<TSingletonClass>.Initialize(this);
        }

        /// <summary>
        ///     Gets the single Instance of the specified Singleton class
        /// </summary>
        public static TSingletonClass Instance
        {
            get { return SingletonMaker<TSingletonClass>.Instance; }
        }

        /// <summary>
        ///     Gets a value indicating whether the given class requires special initialization handling and just calling its
        ///     default constructor it's not enough.
        /// </summary>
        protected static bool RequiresInitialization
        {
            get { return SingletonMaker<TSingletonClass>.RequiresInitialization; }
        }

        /// <summary>
        ///     Initializes the singleton with the provided instance <paramref name="value" />.
        /// </summary>
        /// <param name="value">
        ///     The instance to assign as *the* singleton instance.
        /// </param>
        protected static void Initialize(TSingletonClass value)
        {
            SingletonMaker<TSingletonClass>.Initialize(value);
        }
    }
}