// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SingletonMaker.cs" company="Tenaris S.A.">
//   Copyright � TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the SingletonMaker type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Framework/SingletonMaker.cs $
//  $Id: SingletonMaker.cs 53966 2011-08-09 21:48:19Z apre2k\t61248 $

using System;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using Tenaris.Library.Log.Utility.Activator;

namespace Tenaris.Library.Log.Framework
{
    using System.Security;

    /// <summary>
    ///     Provides as service the creation of singleton instance of any class given.
    /// </summary>
    /// <typeparam name="TSingletonClass">
    ///     A type representing a class that is required to be singleton.
    /// </typeparam>
    internal static class SingletonMaker<TSingletonClass>
        where TSingletonClass : class
    {
        [SuppressMessage("Tiobe.StyleCopRules.TiobeAnalyzer", "TI3102:IdentifiersShouldHaveCorrectCasing",
            Justification = "Reviewed. Suppression is OK here.")] private static readonly object SyncRoot = new object();

        private static TSingletonClass instance;

        static SingletonMaker()
        {
            var attribute = RequiresInitializationAttribute.GetInstance(typeof(TSingletonClass));
            RequiresInitialization = attribute != null;
            FailOnDefaultCreationAttempt = attribute != null && attribute.FailOnDefaultCreationAttempt;
        }

        /// <summary>
        ///     Gets the single Instance of the specified Singleton class
        /// </summary>
        public static TSingletonClass Instance
        {
            [SecuritySafeCritical]
            get
            {
                lock (SyncRoot)
                {
                    return instance ?? (instance = Create());
                }
            }
        }

        /// <summary>
        ///     Gets a value indicating whether the singleton is already initialized.
        /// </summary>
        public static bool IsInitialized
        {
            get
            {
                lock (SyncRoot)
                {
                    return instance != null;
                }
            }
        }

        /// <summary>
        ///     Gets a value indicating whether the given class requires special initialization handling and just calling its
        ///     default constructor it's not enough.
        /// </summary>
        internal static bool RequiresInitialization { get; private set; }

        private static bool FailOnDefaultCreationAttempt { get; set; }

        /// <summary>
        ///     Initializes the singleton with the provided instance <paramref name="value" />.
        /// </summary>
        /// <param name="value">
        ///     The instance to assign as *the* singleton instance.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     When <paramref name="value" /> == null.
        /// </exception>
        /// <exception cref="InvalidOperationException">
        ///     When <see cref="instance" /> != null.
        /// </exception>
        public static void Initialize(TSingletonClass value)
        {
            if (value == null)
            {
                throw new ArgumentNullException("value");
            }

            lock (SyncRoot)
            {
                if (instance != null)
                {
                    throw new InvalidOperationException("The singleton instance is already initialized.");
                }

                instance = value;
            }
        }

        /// <summary>
        ///     Initializes the singleton with the provided instance <paramref name="value" />.
        /// </summary>
        /// <param name="value">
        ///     The instance to assign as *the* singleton instance.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     When <paramref name="value" /> == null.
        /// </exception>
        /// <exception cref="InvalidOperationException">
        ///     When <see cref="instance" /> != null.
        /// </exception>
        public static void Initialize(object value)
        {
            if (value == null)
            {
                throw new ArgumentNullException("value");
            }

            Initialize(value as TSingletonClass ?? InvalidCast(value.GetType()));
        }

        /// <summary>
        ///     Throws an <see cref="InvalidCastException" /> indicating that the given instance type couldn't be converted to
        ///     TSingletonClass type.
        /// </summary>
        /// <param name="type">
        ///     The instance type received.
        /// </param>
        /// <returns>
        ///     It never returns anything since it's sole purpose is to raise an exception.
        /// </returns>
        internal static TSingletonClass InvalidCast(Type type)
        {
            var errorMessage = string.Format(
                "The instance given (type: '{0}') is not convertible to the required singleton type: '{1}'. In order to use this class the type parameter should be a class that inherits from {2}",
                type.AssemblyQualifiedName,
                typeof(TSingletonClass),
                typeof(RemotableSingleton<>).Name);
            throw new InvalidCastException(errorMessage);
        }

        [SecurityCritical]
        private static TSingletonClass Create()
        {
            if (RequiresInitialization)
            {
                if (FailOnDefaultCreationAttempt)
                {
                    throw new NullReferenceException(
                        string.Format(
                            "This singleton class '{0}' requires special initialization handling that was not done yet, and it cannot be created on-demand. Maybe you should not be using this class in the context you're using it? The most probable error is that this code is being executed in the wrong AppDomain (i.e. one that doesn't host the requested singleton type)",
                            typeof(TSingletonClass).AssemblyQualifiedName));
                }

                return null;
            }

            return Factory.Create<TSingletonClass>(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
        }
    }
}