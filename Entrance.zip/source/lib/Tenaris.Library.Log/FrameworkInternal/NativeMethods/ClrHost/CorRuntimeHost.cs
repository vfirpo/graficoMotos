﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CorRuntimeHost.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the CorRuntimeHost type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/NativeMethods/ClrHost/CorRuntimeHostClass.cs $
// $Id: CorRuntimeHostClass.cs 30227 2010-03-15 16:47:28Z apre2k\t61248 $

using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Tenaris.Library.Log.NativeMethods.ClrHost
{
    /// <summary>
    /// </summary>
    [ComImport]
    [ClassInterface(ClassInterfaceType.None)]
    [TypeLibType(TypeLibTypeFlags.FCanCreate)]
    [Guid("CB2F6723-AB3A-11D2-9C40-00C04FA30A3E")]
    [ComConversionLoss]
    internal class CorRuntimeHost : ICorRuntimeHost
    {
        // Methods
        /// <summary>
        /// </summary>
        /// <param name="hEnum"></param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void CloseEnum([In] IntPtr hEnum);

        /// <summary>
        /// </summary>
        /// <param name="pwzFriendlyName"></param>
        /// <param name="pIdentityArray"></param>
        /// <param name="pAppDomain"></param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void CreateDomain(
            [In] [MarshalAs(UnmanagedType.LPWStr)] string pwzFriendlyName,
            [In] [MarshalAs(UnmanagedType.IUnknown)] object pIdentityArray,
            [MarshalAs(UnmanagedType.IUnknown)] out object pAppDomain);

        /// <summary>
        /// </summary>
        /// <param name="pwzFriendlyName"></param>
        /// <param name="pSetup"></param>
        /// <param name="pEvidence"></param>
        /// <param name="pAppDomain"></param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void CreateDomainEx(
            [In] [MarshalAs(UnmanagedType.LPWStr)] string pwzFriendlyName,
            [In] [MarshalAs(UnmanagedType.IUnknown)] object pSetup,
            [In] [MarshalAs(UnmanagedType.IUnknown)] object pEvidence,
            [MarshalAs(UnmanagedType.IUnknown)] out object pAppDomain);

        /// <summary>
        /// </summary>
        /// <param name="pAppDomainSetup"></param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void CreateDomainSetup([MarshalAs(UnmanagedType.IUnknown)] out object pAppDomainSetup);

        /// <summary>
        /// </summary>
        /// <param name="pEvidence"></param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void CreateEvidence([MarshalAs(UnmanagedType.IUnknown)] out object pEvidence);

        /// <summary>
        /// </summary>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void CreateLogicalThreadState();

        /// <summary>
        /// </summary>
        /// <param name="pAppDomain"></param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void CurrentDomain([MarshalAs(UnmanagedType.IUnknown)] out object pAppDomain);

        /// <summary>
        /// </summary>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void DeleteLogicalThreadState();

        /// <summary>
        /// </summary>
        /// <param name="hEnum"></param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void EnumDomains(out IntPtr hEnum);

        /// <summary>
        /// </summary>
        /// <param name="pConfiguration"></param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void GetConfiguration([MarshalAs(UnmanagedType.Interface)] out object pConfiguration);

        /// <summary>
        /// </summary>
        /// <param name="pAppDomain"></param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void GetDefaultDomain([MarshalAs(UnmanagedType.IUnknown)] out object pAppDomain);

        /// <summary>
        /// </summary>
        /// <param name="pCount"></param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void LocksHeldByLogicalThread(out uint pCount);

        /// <summary>
        /// </summary>
        /// <param name="hFile"></param>
        /// <param name="hMapAddress"></param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void MapFile([In] IntPtr hFile, out IntPtr hMapAddress);

        /// <summary>
        /// </summary>
        /// <param name="hEnum"></param>
        /// <param name="pAppDomain"></param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void NextDomain(
            [In] IntPtr hEnum, [MarshalAs(UnmanagedType.IUnknown)] out object pAppDomain);

        /// <summary>
        /// </summary>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void Start();

        /// <summary>
        /// </summary>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void Stop();

        /// <summary>
        /// </summary>
        /// <param name="pFiberCookie"></param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void SwitchInLogicalThreadState([In] ref uint pFiberCookie);

        /// <summary>
        /// </summary>
        /// <param name="pFiberCookie"></param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void SwitchOutLogicalThreadState([Out] IntPtr pFiberCookie);

        /// <summary>
        /// </summary>
        /// <param name="pAppDomain"></param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        public virtual extern void UnloadDomain([In] [MarshalAs(UnmanagedType.IUnknown)] object pAppDomain);
    }
}