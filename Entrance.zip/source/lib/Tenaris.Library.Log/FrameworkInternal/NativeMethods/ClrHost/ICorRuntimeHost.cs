﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ICorRuntimeHost.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the ICorRuntimeHost type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/NativeMethods/ClrHost/ICorRuntimeHost.cs $
// $Id: ICorRuntimeHost.cs 30227 2010-03-15 16:47:28Z apre2k\t61248 $

using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Tenaris.Library.Log.NativeMethods.ClrHost
{
    /// <summary>
    /// </summary>
    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [ComConversionLoss]
    [Guid("CB2F6722-AB3A-11D2-9C40-00C04FA30A3E")]
    internal interface ICorRuntimeHost
    {
        /// <summary>
        ///     Creates the state of the logical thread.
        /// </summary>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void CreateLogicalThreadState();

        /// <summary>
        ///     Deletes the state of the logical thread.
        /// </summary>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void DeleteLogicalThreadState();

        /// <summary>
        ///     Switches the state of the in logical thread.
        /// </summary>
        /// <param name="pFiberCookie">The p fiber cookie.</param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void SwitchInLogicalThreadState([In] ref uint pFiberCookie);

        /// <summary>
        ///     Switches the state of the out logical thread.
        /// </summary>
        /// <param name="pFiberCookie">The p fiber cookie.</param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void SwitchOutLogicalThreadState([Out] IntPtr pFiberCookie);

        /// <summary>
        ///     Lockses the held by logical thread.
        /// </summary>
        /// <param name="pCount">The p count.</param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void LocksHeldByLogicalThread(out uint pCount);

        /// <summary>
        ///     Maps the file.
        /// </summary>
        /// <param name="hFile">The h file.</param>
        /// <param name="hMapAddress">The h map address.</param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void MapFile([In] IntPtr hFile, out IntPtr hMapAddress);

        /// <summary>
        ///     Gets the configuration.
        /// </summary>
        /// <param name="pConfiguration">The p configuration.</param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void GetConfiguration([MarshalAs(UnmanagedType.Interface)] out object pConfiguration);

        /// <summary>
        ///     Starts this instance.
        /// </summary>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void Start();

        /// <summary>
        ///     Stops this instance.
        /// </summary>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void Stop();

        /// <summary>
        ///     Creates the domain.
        /// </summary>
        /// <param name="pwzFriendlyName">Name of the PWZ friendly.</param>
        /// <param name="pIdentityArray">The p identity array.</param>
        /// <param name="pAppDomain">The p app domain.</param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void CreateDomain(
            [In] [MarshalAs(UnmanagedType.LPWStr)] string pwzFriendlyName,
            [In] [MarshalAs(UnmanagedType.IUnknown)] object pIdentityArray,
            [MarshalAs(UnmanagedType.IUnknown)] out object pAppDomain);

        /// <summary>
        ///     Gets the default domain.
        /// </summary>
        /// <param name="pAppDomain">The p app domain.</param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void GetDefaultDomain([MarshalAs(UnmanagedType.IUnknown)] out object pAppDomain);

        /// <summary>
        ///     Enums the domains.
        /// </summary>
        /// <param name="hEnum">The h enum.</param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void EnumDomains(out IntPtr hEnum);

        /// <summary>
        ///     Nexts the domain.
        /// </summary>
        /// <param name="hEnum">The h enum.</param>
        /// <param name="pAppDomain">The p app domain.</param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void NextDomain([In] IntPtr hEnum, [MarshalAs(UnmanagedType.IUnknown)] out object pAppDomain);

        /// <summary>
        ///     Closes the enum.
        /// </summary>
        /// <param name="hEnum">The h enum.</param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void CloseEnum([In] IntPtr hEnum);

        /// <summary>
        ///     Creates the domain ex.
        /// </summary>
        /// <param name="pwzFriendlyName">Name of the PWZ friendly.</param>
        /// <param name="pSetup">The p setup.</param>
        /// <param name="pEvidence">The p evidence.</param>
        /// <param name="pAppDomain">The p app domain.</param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void CreateDomainEx(
            [In] [MarshalAs(UnmanagedType.LPWStr)] string pwzFriendlyName,
            [In] [MarshalAs(UnmanagedType.IUnknown)] object pSetup,
            [In] [MarshalAs(UnmanagedType.IUnknown)] object pEvidence,
            [MarshalAs(UnmanagedType.IUnknown)] out object pAppDomain);

        /// <summary>
        ///     Creates the domain setup.
        /// </summary>
        /// <param name="pAppDomainSetup">The p app domain setup.</param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void CreateDomainSetup([MarshalAs(UnmanagedType.IUnknown)] out object pAppDomainSetup);

        /// <summary>
        ///     Creates the evidence.
        /// </summary>
        /// <param name="pEvidence">The p evidence.</param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void CreateEvidence([MarshalAs(UnmanagedType.IUnknown)] out object pEvidence);

        /// <summary>
        ///     Unloads the domain.
        /// </summary>
        /// <param name="pAppDomain">The p app domain.</param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void UnloadDomain([In] [MarshalAs(UnmanagedType.IUnknown)] object pAppDomain);

        /// <summary>
        ///     Currents the domain.
        /// </summary>
        /// <param name="pAppDomain">The p app domain.</param>
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
        void CurrentDomain([MarshalAs(UnmanagedType.IUnknown)] out object pAppDomain);
    }
}