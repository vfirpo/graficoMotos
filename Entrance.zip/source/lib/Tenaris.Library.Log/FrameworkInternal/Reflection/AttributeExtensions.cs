﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="Tenaris S.A." file="AttributeExtensions.cs">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Extension methods for System.Attribute
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Reflection/AttributeExtensions.cs $
// $Id: AttributeExtensions.cs 50155 2011-03-01 18:19:58Z apre2k\t61248 $

using System;
using System.Reflection;

namespace Tenaris.Library.Log.Reflection
{
    /// <summary>
    ///     Extension methods for System.Attribute
    /// </summary>
    internal static class AttributeExtensions
    {
        /// <summary>
        ///     Gets the specified Attribute from the specified member info.
        /// </summary>
        /// <typeparam name="TAttribute">
        ///     The Attribute type
        /// </typeparam>
        /// <param name="info">
        ///     The Member on which to check
        /// </param>
        /// <param name="inherit">
        ///     Whether or not to look on the inheritance chain
        /// </param>
        /// <returns>
        ///     The attribute instance if present or null otherwise.
        /// </returns>
        public static TAttribute GetAttribute<TAttribute>(this MemberInfo info, bool inherit = false)
            where TAttribute : Attribute
        {
            return (TAttribute) Attribute.GetCustomAttribute(info, typeof(TAttribute), inherit);
        }

        /// <summary>
        ///     Gets the specified Attribute from the specified Parameter
        /// </summary>
        /// <typeparam name="TAttribute">
        ///     The Attribute type
        /// </typeparam>
        /// <param name="info">
        ///     The Member on which to check
        /// </param>
        /// <param name="inherit">
        ///     Whether or not to look on the inheritance chain
        /// </param>
        /// <returns>
        ///     The attribute instance if present or null otherwise.
        /// </returns>
        public static TAttribute GetAttribute<TAttribute>(this ParameterInfo info, bool inherit = false)
            where TAttribute : Attribute
        {
            return (TAttribute) Attribute.GetCustomAttribute(info, typeof(TAttribute), inherit);
        }
    }
}