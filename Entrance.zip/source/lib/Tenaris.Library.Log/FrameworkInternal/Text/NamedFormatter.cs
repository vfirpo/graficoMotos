﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="NamedFormatter.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   An extension to the String.Format. It replaces the index based placeholder with named placeholders.
//   Basically you give to this function a format string just like the one you give to String.Format but
//   like this "{Name}, {LastName}. Age {Age:d2}". Then it will complete the data calling the properties
//   of an object (in the previous example, you should pass to the function an object with a Name, LastName
//   Age property.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Text/NamedFormatter.cs $
// $Id: NamedFormatter.cs 32392 2010-06-27 03:47:42Z apre2k\15827 $

using System;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

namespace Tenaris.Library.Log.Text
{
    /// <summary>
    ///     An extension to the String.Format. It replaces the index based placeholder with named placeholders.
    ///     Basically you give to this function a format string just like the one you give to String.Format but
    ///     like this "{Name}, {LastName}. Age {Age:d2}". Then it will complete the data calling the properties
    ///     of an object (in the previous example, you should pass to the function an object with a Name, LastName
    ///     Age property.
    /// </summary>
    internal class NamedFormatter
    {
        private readonly PropertyInfo[] propsInfos = {};
        private readonly object[] propsValues;
        private readonly string template;

        /// <summary>
        ///     Initializes a new instance of the <see cref="NamedFormatter" /> class.
        ///     Constructor for a named formmater.
        /// </summary>
        /// <param name="templateString">
        ///     The string template. In the form of (example) "{Name}, {LastName}. Age {Age:d2}".
        /// </param>
        /// <param name="objectType">
        ///     The type of the object to use further on to replace the template.
        /// </param>
        public NamedFormatter(string templateString, Type objectType)
        {
            var r = new Regex(@"\{(?<id>\w+(\.\w+)*)(?<param>[:,][^}]+)?\}");
            var result = new StringBuilder();

            var index = 0;
            var i = 0;
            foreach (Match m in r.Matches(templateString))
            {
                if (index < m.Index)
                {
                    result.Append(templateString.Substring(index, m.Index - index));
                }

                var id = m.Groups["id"];
                var param = m.Groups["param"];

                var t = @"{" + i + param + @"}";
                result.Append(t);

                Array.Resize(ref propsInfos, i + 1);
                propsInfos[i] = objectType.GetProperty(id.ToString());

                i++;
                index = m.Index + m.Length;
            }

            if (index < templateString.Length)
            {
                result.Append(templateString.Substring(index));
            }

            template = result.ToString();
            propsValues = new object[propsInfos.Length];
        }

        /// <summary>
        ///     Formats the template given in the constructor with the given object data.
        /// </summary>
        /// <param name="formatProvider">The format provider to use.</param>
        /// <param name="value">The object to use as data source.</param>
        /// <returns>The formatted string.</returns>
        public string Format(IFormatProvider formatProvider, object value)
        {
            for (var i = 0; i < propsInfos.Length; i++)
            {
                propsValues[i] = propsInfos[i].GetValue(value, BindingFlags.GetField, null, null, null);
            }

            return string.Format(formatProvider, template, propsValues);
        }
    }
}