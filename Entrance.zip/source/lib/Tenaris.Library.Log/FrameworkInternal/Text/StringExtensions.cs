﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="StringExtensions.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Named formatter StringExtensions methods.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Text/StringExtensions.cs $
// $Id: StringExtensions.cs 56158 2011-12-01 21:40:31Z apre2k\t61248 $

using System;
using System.Collections.Generic;
using System.Text;

namespace Tenaris.Library.Log.Text
{
    /// <summary>
    ///     Named formatter StringExtensions methods.
    /// </summary>
    internal static class StringExtensions
    {
        private static readonly char[] PhraseSeparator = {' ', '-', '.', '_'};

        private static readonly Dictionary<int, Dictionary<int, NamedFormatter>> Formatters =
            new Dictionary<int, Dictionary<int, NamedFormatter>>();

        /// <summary>
        ///     Encapsulate the use of NamedFormatter.Format. Just pass to the function the format and the object
        ///     used as data source and it will replace the format string with the data in the object.
        /// </summary>
        /// <param name="format">The template string.</param>
        /// <param name="formatProvider">The format provider to use.</param>
        /// <param name="value">The object to use as data source.</param>
        /// <param name="cache">If true, the template will be cached to speed up (significantly) further calls.</param>
        /// <returns>The formatted string.</returns>
        public static string Inject(this string format, IFormatProvider formatProvider, object value, bool cache)
        {
            NamedFormatter formatter;
            if (!cache)
            {
                formatter = new NamedFormatter(format, value.GetType());
            }
            else
            {
                var typeHash = value.GetType().GetHashCode();
                var formatHash = format.GetHashCode();
                if (Formatters.ContainsKey(typeHash))
                {
                    if (Formatters[typeHash].ContainsKey(formatHash))
                    {
                        formatter = Formatters[typeHash][formatHash];
                    }
                    else
                    {
                        formatter = new NamedFormatter(format, value.GetType());
                        Formatters[typeHash].Add(formatHash, formatter);
                    }
                }
                else
                {
                    Formatters.Add(typeHash, new Dictionary<int, NamedFormatter>());
                    formatter = new NamedFormatter(format, value.GetType());
                    Formatters[typeHash].Add(formatHash, formatter);
                }
            }

            return formatter.Format(formatProvider, value);
        }

        /// <summary>
        ///     Encapsulate the use of NamedFormatter.Format. Just pass to the function the format and the object
        ///     used as data source and it will replace the format string with the data in the object.
        /// </summary>
        /// <param name="format">The template string.</param>
        /// <param name="value">The object to use as data source.</param>
        /// <param name="cache">If true, the template will be cached to speed up (significantly) further calls.</param>
        /// <returns>The formatted string.</returns>
        public static string Inject(this string format, object value, bool cache)
        {
            return format.Inject(null, value, cache);
        }

        /// <summary>
        ///     Encapsulate the use of NamedFormatter.Format. Just pass to the function the format and the object
        ///     used as data source and it will replace the format string with the data in the object. It will
        ///     cache all the type info necessary to speed up further calls to this method.
        /// </summary>
        /// <param name="format">The template string.</param>
        /// <param name="value">The object to use as data source.</param>
        /// <returns>The formatted string.</returns>
        public static string Inject(this string format, object value)
        {
            return format.Inject(value, true);
        }

        /// <summary>
        ///     Formats a string <paramref name="format" /> value and then appends it to a <see cref="StringBuilder" /> separated
        ///     by the given separator.
        ///     The separator is added only if the existing StringBuilder is not empty.
        /// </summary>
        /// <param name="builder">
        ///     The StringBuilder to which this methods applies.
        /// </param>
        /// <param name="separator">
        ///     The separator value to use.
        /// </param>
        /// <param name="format">
        ///     The format string value.
        /// </param>
        /// <param name="args">
        ///     The arguments used for formatting.
        /// </param>
        /// <returns>
        ///     The new string formed by the existing value and the separator if the former is non empty, and the new value
        ///     appended.
        /// </returns>
        public static StringBuilder AppendValue(this StringBuilder builder, string separator, string format,
            params object[] args)
        {
            if (builder == null)
            {
                builder = new StringBuilder();
            }

            if (builder.Length > 0)
            {
                builder.Append(separator);
            }

            return builder.AppendFormat(format, args);
        }
    }
}