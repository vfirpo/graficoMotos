﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ThreadExtensions.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Thread class extension methods.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Threading/ThreadExtensions.cs $
// $Id: ThreadExtensions.cs 50155 2011-03-01 18:19:58Z apre2k\t61248 $

using System.Collections.Generic;
using System.Threading;

namespace Tenaris.Library.Log.Threading
{
    /// <summary>
    ///     Thread class extension methods.
    /// </summary>
    internal static class ThreadExtensions
    {
        private static readonly Dictionary<int, ThreadExitCallbackContext> ThreadExitCallbackContexts =
            new Dictionary<int, ThreadExitCallbackContext>();

        /// <summary>
        ///     Callback passed to this method will be invoked on thread exit. State is a context object with
        ///     user defined data.
        /// </summary>
        /// <param name="thread">The thread on which the method is executed.</param>
        /// <param name="callback"> The callback to call upon thread finalization.</param>
        /// <param name="state">The user defined object to pass to the callback on invocation.</param>
        public static void ThreadExitCallback(this Thread thread, ContextCallback callback, object state)
        {
            var threadId = thread.ManagedThreadId;
            if (ThreadExitCallbackContexts.ContainsKey(threadId))
            {
                ThreadExitCallbackContexts[threadId].Subscribers.Add(callback, state);
            }
            else
            {
                var callbackContext = new ThreadExitCallbackContext
                {
                    WaitingThread = new Thread(WaitForThreadExit) {Priority = ThreadPriority.Lowest},
                    SyncronizingThread = thread,
                    Subscribers = new Dictionary<ContextCallback, object> {{callback, state}}
                };
                ThreadExitCallbackContexts.Add(threadId, callbackContext);
                callbackContext.WaitingThread.Start(threadId);
            }
        }

        private static void WaitForThreadExit(object context)
        {
            var threadId = (int) context;
            var syncThread = ThreadExitCallbackContexts[threadId].SyncronizingThread;

            while (syncThread.IsAlive)
            {
                Thread.Sleep(100);
            }

            var subscribers = ThreadExitCallbackContexts[threadId].Subscribers;
            foreach (var subscriber in subscribers)
            {
                subscriber.Key(subscriber.Value);
            }

            ThreadExitCallbackContexts.Remove(threadId);
        }

        /// <summary>
        ///     Represents a set of callback to call when the specified thread ends.
        /// </summary>
        private struct ThreadExitCallbackContext
        {
            public Thread WaitingThread;

            public Thread SyncronizingThread;

            public Dictionary<ContextCallback, object> Subscribers;
        }
    }
}