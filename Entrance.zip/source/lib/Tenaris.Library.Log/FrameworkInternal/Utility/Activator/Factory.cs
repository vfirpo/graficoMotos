﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Factory.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the Factory type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Utility/Activator/Factory.cs $
// $Id: Factory.cs 31276 2010-04-16 21:07:12Z apre2k\t61248 $

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;

namespace Tenaris.Library.Log.Utility.Activator
{
    using System.Security;

    /// <summary>
    ///     Class to provide dynamic instance creation facilities
    /// </summary>
    [SecurityCritical]
    internal static class Factory
    {
        private const BindingFlags DefaultBindingFlags = BindingFlags.Default;

        /// <summary>
        ///     Creates a new instance of type T using the default constructor.
        /// </summary>
        /// <param name="type">The type to create.</param>
        /// <param name="bindingFlags">The binding flags to pass to Activator.CreateInstance</param>
        /// <param name="binder">The binder obejct to pass to Activator.CreateInstance</param>
        /// <param name="cultureInfo">The CultureInfo to pass to Activator.CreateInstance</param>
        /// <typeparam name="TReturnType">The type to return.</typeparam>
        /// <returns>The new created instance.</returns>
        public static TReturnType Create<TReturnType>(Type type, BindingFlags bindingFlags = DefaultBindingFlags,
            Binder binder = null,
            CultureInfo cultureInfo = null)
            where TReturnType : class
        {
            return (TReturnType) System.Activator.CreateInstance(type, bindingFlags, binder, null, cultureInfo);
        }

        /// <summary>
        ///     Instantiates T without calling a constructor.
        ///     Works well with otherwise uninstantiable objects.
        /// </summary>
        /// <typeparam name="TReturnType">
        ///     Anything that does NOT derive
        ///     from ContextBoundObject.
        /// </typeparam>
        /// <param name="values">
        ///     A dictionary of values to initialize
        ///     the object in place of a constructor.
        /// </param>
        /// <param name="strict">
        ///     If set to true (default value) an exceptino will be thrown if there are more
        ///     parameters specified in values that the ones the class has or if the parameters are not assignables
        ///     to the class fields or properties.
        /// </param>
        /// <returns>The newly created and instantiated object.</returns>
        public static TReturnType Create<TReturnType>(Dictionary<string, object> values, bool strict = true)
            where TReturnType : class
        {
            if (values == null)
            {
                throw new ArgumentNullException("values", "Values is null.");
            }

            return Fill(CreateBlank<TReturnType>(), values, strict);
        }

        /// <summary>
        ///     Creates a new instance of type T using the default constructor
        /// </summary>
        /// <param name="type">The type to create.</param>
        /// <param name="bindingFlags">The binding flags to pass to Activator.CreateInstance</param>
        /// <param name="args">The arguments to pass to the constructor</param>
        /// <typeparam name="TReturnType">The type to create</typeparam>
        /// <returns>The new created instance</returns>
        public static TReturnType Create<TReturnType>(Type type, object[] args,
            BindingFlags bindingFlags = DefaultBindingFlags) where TReturnType : class
        {
            return (TReturnType) System.Activator.CreateInstance(type, bindingFlags, null, args, null);
        }

        /// <summary>
        ///     Creates a new instance of T using the default constructor
        /// </summary>
        /// <param name="bindingFlags">The binding flags to pass to Activator.CreateInstance</param>
        /// <param name="binder">The binder obejct to pass to Activator.CreateInstance</param>
        /// <param name="cultureInfo">The CultureInfo to pass to Activator.CreateInstance</param>
        /// <typeparam name="TCreatableType">The type to create</typeparam>
        /// <typeparam name="TReturnType">The type to return</typeparam>
        /// <returns>The new created instance</returns>
        public static TReturnType Create<TCreatableType, TReturnType>(
            BindingFlags bindingFlags = BindingFlags.Instance | BindingFlags.Public,
            Binder binder = null, CultureInfo cultureInfo = null)
        {
            return
                (TReturnType)
                    System.Activator.CreateInstance(typeof(TCreatableType), bindingFlags, binder, null, cultureInfo);
        }

        /// <summary>
        ///     Creates a new instance of T using the default constructor
        /// </summary>
        /// <param name="bindingFlags">The Binding flags</param>
        /// <param name="binder">The Binder object</param>
        /// <param name="cultureInfo">A culture info</param>
        /// <param name="args">The arguments to pass to the constructor</param>
        /// <typeparam name="TCreatableType">The type to create</typeparam>
        /// <typeparam name="TReturnType">The type to return</typeparam>
        /// <returns>The new created instance</returns>
        public static TReturnType Create<TCreatableType, TReturnType>(object[] args,
            BindingFlags bindingFlags = BindingFlags.Instance | BindingFlags.Public,
            Binder binder = null, CultureInfo cultureInfo = null) where TReturnType : class
        {
            return
                (TReturnType)
                    System.Activator.CreateInstance(typeof(TCreatableType), bindingFlags, binder, args, cultureInfo);
        }

        /// <summary>
        ///     Creates a new instance of T using the default constructor
        /// </summary>
        /// <param name="bindingFlags">The binding flags to pass to Activator.CreateInstance</param>
        /// <param name="binder">The binder obejct to pass to Activator.CreateInstance</param>
        /// <param name="cultureInfo">The CultureInfo to pass to Activator.CreateInstance</param>
        /// <typeparam name="TCreatableType">The type to create and return</typeparam>
        /// <returns>The new created instance</returns>
        public static TCreatableType Create<TCreatableType>(
            BindingFlags bindingFlags = BindingFlags.Instance | BindingFlags.Public,
            Binder binder = null, CultureInfo cultureInfo = null) where TCreatableType : class
        {
            return Create<TCreatableType, TCreatableType>(bindingFlags, binder, cultureInfo);
        }

        /// <summary>
        ///     Creates a new instance of T using the default constructor
        /// </summary>
        /// <param name="bindingFlags">The Binding flags</param>
        /// <param name="binder">The Binder object</param>
        /// <param name="cultureInfo">A culture info</param>
        /// <param name="args">The arguments to pass to the constructor</param>
        /// <typeparam name="TCreatableType">The type to create and return</typeparam>
        /// <returns>The new created instance</returns>
        public static TCreatableType Create<TCreatableType>(object[] args,
            BindingFlags bindingFlags = BindingFlags.Instance | BindingFlags.Public,
            Binder binder = null, CultureInfo cultureInfo = null) where TCreatableType : class
        {
            return Create<TCreatableType, TCreatableType>(args, bindingFlags, binder, cultureInfo);
        }

        private static T CreateBlank<T>()
        {
            if (typeof(ContextBoundObject).IsAssignableFrom(typeof(T)))
            {
                throw new ApplicationException("You can't use types that derive from ContextBoundObject.");
            }

            return (T) FormatterServices.GetUninitializedObject(typeof(T));
        }

        private static T Fill<T>(T source, ICollection<KeyValuePair<string, object>> values, bool strict)
            where T : class
        {
            if (source == null)
            {
                throw new ArgumentNullException("source", "Source is null.");
            }

            if (values == null)
            {
                throw new ArgumentNullException("values", "Values is null");
            }

            if (values.Count == 0)
            {
                return source;
            }

            var fields = typeof(T).GetFields(
                BindingFlags.NonPublic |
                BindingFlags.Public |
                BindingFlags.Instance |
                BindingFlags.DeclaredOnly);

            foreach (var value in values)
            {
                var fieldName = value.Key;
                var fieldValue = value.Value;

                var field = strict
                    ? fields.Single(arg => arg.Name == fieldName)
                    : fields.SingleOrDefault(arg => arg.Name == fieldName);

                if (field != null)
                {
                    if (field.FieldType.IsAssignableFrom(fieldValue.GetType()) || !strict)
                    {
                        field.SetValue(source, fieldValue);
                    }
                }
            }

            return source;
        }
    }
}