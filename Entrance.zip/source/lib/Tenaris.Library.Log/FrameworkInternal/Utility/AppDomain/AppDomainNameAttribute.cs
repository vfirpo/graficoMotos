﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AppDomainNameAttribute.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the AppDomainNameAttribute type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Utility/AppDomain/AppDomainNameAttribute.cs $
// $Id: AppDomainNameAttribute.cs 53966 2011-08-09 21:48:19Z apre2k\t61248 $

using System;
using System.ComponentModel;
using System.Reflection;
using Tenaris.Library.Log.Reflection;

namespace Tenaris.Library.Log.Utility.AppDomain
{
    /// <summary>
    ///     Attribute used to define the AppDomain name for when using cross-appdomain singletons. It will mark the AppDomain
    ///     to use as host for the singleton
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, Inherited = false)]
    internal sealed class AppDomainNameAttribute : Attribute
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="AppDomainNameAttribute" /> class.
        /// </summary>
        public AppDomainNameAttribute()
        {
            AppDomainName = null;
            UseDefaultDomain = true;
        }

        /// <summary>
        ///     Gets or sets the AppDomain specified at creation time (or null).
        /// </summary>
        [DefaultValue(null)]
        public string AppDomainName { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether to search for the default AppDomain or to used the default calling code's
        ///     AppDomain.
        /// </summary>
        [DefaultValue(true)]
        public bool UseDefaultDomain { get; set; }

        /// <summary>
        /// </summary>
        /// <param name="member"></param>
        /// <returns></returns>
        internal static AppDomainNameAttribute GetInstance(MemberInfo member)
        {
            return member.GetAttribute<AppDomainNameAttribute>() ?? new AppDomainNameAttribute();
        }
    }
}