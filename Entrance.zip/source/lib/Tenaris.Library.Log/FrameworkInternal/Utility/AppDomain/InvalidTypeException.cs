﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="InvalidTypeException.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Exception raised when Type used to instantiate the ProcessSingleton class is invalid somehow
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: $
// $Id: $

using System;
using System.Runtime.Serialization;

namespace Tenaris.Library.Log.Utility.AppDomain
{
    /// <summary>
    ///     Exception raised when Type used to instantiate the ProcessSingleton class is invalid somehow
    /// </summary>
    [Serializable]
    internal class InvalidTypeException : ApplicationException
    {
        /// <summary>
        ///     Creates a new instance of the InvalidTypeException with no message.
        /// </summary>
        public InvalidTypeException()
        {
        }

        /// <summary>
        ///     Creates a new instance of the InvalidTypeException the specified message.
        /// </summary>
        /// <param name="message">Message describing the error.</param>
        public InvalidTypeException(string message)
            : base(message)
        {
        }

        /// <summary>
        ///     Creates a new instance of the InvalidTypeException the specified message and an inner exception.
        /// </summary>
        /// <param name="message">Message describing the error.</param>
        /// <param name="inner">Inner exception that caused the code to abort.</param>
        public InvalidTypeException(string message, Exception inner)
            : base(message, inner)
        {
        }

        /// <summary>
        ///     Initializes a new instance of the InvalidTypeException class with serialized data.
        /// </summary>
        /// <param name="info"></param>
        /// <param name="context"></param>
        protected InvalidTypeException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}