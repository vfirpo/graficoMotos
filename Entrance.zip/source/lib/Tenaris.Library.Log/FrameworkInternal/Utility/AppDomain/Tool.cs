﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Tool.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the Tool type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Utility/AppDomain/Tool.cs $
// $Id: Tool.cs 30275 2010-03-16 16:53:28Z apre2k\t61248 $

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using Tenaris.Library.Log.NativeMethods.ClrHost;

namespace Tenaris.Library.Log.Utility.AppDomain
{
    using System.Security;

    /// <summary>
    ///     Static class with utility methods related to the AppDomain class.
    /// </summary>
    [SecurityCritical]
    internal static class Tool
    {
        /// <summary>
        ///     Gets the list of AppDomains currently active.
        /// </summary>
        /// <returns>
        ///     An enumerable sequence of AppDomain instances.
        /// </returns>
        public static IEnumerable<System.AppDomain> Enumerate()
        {
            var host = new CorRuntimeHost();

            var list = new List<System.AppDomain>();
            try
            {
                IntPtr enumHandle;
                host.EnumDomains(out enumHandle);

                try
                {
                    while (true)
                    {
                        object appDomain;
                        host.NextDomain(enumHandle, out appDomain);

                        if (appDomain == null)
                        {
                            break;
                        }

                        list.Add((System.AppDomain)appDomain);
                    }

                    return list;
                }
                finally
                {
                    host.CloseEnum(enumHandle);
                }
            }
            finally
            {
                Marshal.ReleaseComObject(host);
            }
        }

        /// <summary>
        ///     Tries to find an AppDomain instance searching by the specified friendly name
        /// </summary>
        /// <param name="friendlyName">The friendly name to find</param>
        /// <returns>The AppDomain found, or null otherwise</returns>
        public static System.AppDomain Find(string friendlyName)
        {
            return Find(appDomain => appDomain.FriendlyName.Equals(friendlyName));
        }

        /// <summary>
        ///     Tries to find an AppDomain instance searching by using a predicate on every AppDomain
        /// </summary>
        /// <param name="predicate">Code-block to evaluate on each AppDomain</param>
        /// <returns>The AppDomain found, or null otherwise</returns>
        public static System.AppDomain Find(Func<System.AppDomain, bool> predicate)
        {
          return Enumerate().FirstOrDefault(predicate);
        }

        /// <summary>
        ///     Tries to find an AppDomain instance searching by using a predicate on every AppDomain
        /// </summary>
        /// <param name="predicate">Code-block to evaluate on each AppDomain</param>
        /// <param name="appDomain">The AppDomain found, or null otherwise</param>
        /// <returns>True is an AppDomain matches the search or False otherwise</returns>
        public static bool Find(Func<System.AppDomain, bool> predicate, out System.AppDomain appDomain)
        {
            appDomain = Enumerate().First(predicate);
            return appDomain != null;
        }

        /// <summary>
        ///     Tries to find the global default AppDomain for the local process.
        /// </summary>
        /// <returns>The AppDomain instance which returned IsDefaultAppDomain() ==  true, or null if none did.</returns>
        public static System.AppDomain GetDefault()
        {
            System.AppDomain appDomain;
            return Find(x => x.IsDefaultAppDomain(), out appDomain) ? appDomain : null;
        }

        /// <summary>
        ///     Tries to find an AppDomain with the given name, and if not found then creates a new one based on the specified
        ///     arguments.
        /// </summary>
        /// <param name="friendlyName">The AppDomain name</param>
        /// <param name="parentDomain">The AppDomain used to copy the settings for the new one.</param>
        /// <returns>The existing AppDomain or one newly created</returns>
        public static System.AppDomain GetDomain(string friendlyName, System.AppDomain parentDomain)
        {
          if (string.IsNullOrEmpty(friendlyName)) {
            return parentDomain;
          }

          return Find(friendlyName) ?? System.AppDomain.CreateDomain(friendlyName, parentDomain.Evidence, parentDomain.SetupInformation);
        }
    }
}