﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ConversionFailedException.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Exception raised when an attempted conversion fails.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Utility/Conversion/ConversionFailedException.cs $
// $Id: ConversionFailedException.cs 31276 2010-04-16 21:07:12Z apre2k\t61248 $

using System;
using System.Runtime.Serialization;

namespace Tenaris.Library.Log.Utility.Conversion
{
    /// <summary>
    ///     Exception raised when an attempted conversion fails.
    /// </summary>
    [Serializable]
    internal class ConversionFailedException : ApplicationException
    {
        /// <summary>
        ///     Initializes the new instance with a default message text.
        /// </summary>
        public ConversionFailedException()
        {
        }

        /// <summary>
        ///     Initializes the new instance with the specified message text.
        /// </summary>
        /// <param name="message">The error message text.</param>
        public ConversionFailedException(string message)
            : base(message)
        {
        }

        /// <summary>
        ///     Initializes the new instance with the specified message text and an inner exception.
        /// </summary>
        /// <param name="message">The error message text.</param>
        /// <param name="inner">The inner exception.</param>
        public ConversionFailedException(string message, Exception inner)
            : base(message, inner)
        {
        }

        /// <summary>
        ///     Initializes a new instance of the ConversionFailedException class with serialized data.
        /// </summary>
        /// <param name="info"></param>
        /// <param name="context"></param>
        protected ConversionFailedException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}