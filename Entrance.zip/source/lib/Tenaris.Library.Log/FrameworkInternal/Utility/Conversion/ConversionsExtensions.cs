﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ConversionsExtensions.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the ConversionsExtensions type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Utility/Conversion/ConversionExtensions.cs $
// $Id: ConversionExtensions.cs 51126 2011-04-07 19:06:22Z apre2k\t61248 $

namespace Tenaris.Library.Log.Utility.Conversion
{
    /// <summary>
    ///     Adds some useful conversions from/two builtin types.
    /// </summary>
    internal static class ConversionsExtensions
    {
        /// <summary>
        ///     Tries to convert the string value to an integer and if fails returns the specified default.
        /// </summary>
        /// <param name="text">The text to convert to integer.</param>
        /// <param name="defvalue">The default value to use in case the text is invalid.</param>
        /// <param name="raiseError">
        ///     A boolean used to signal if exceptions in case of failed conversion are desired or no (default
        ///     is no)
        /// </param>
        /// <exception cref="ConversionFailedException">Exception raised when the conversion fail and raiseError is true.</exception>
        /// <returns>The converted value.</returns>
        public static int ToInteger(this string text, int defvalue = 0, bool raiseError = false)
        {
            int result;
            if (string.IsNullOrEmpty(text) || !int.TryParse(text.Trim(), out result))
            {
                if (raiseError)
                {
                    throw new ConversionFailedException(
                        string.Format("Couldn't convert the value {0} to {1}", text, typeof(int).Name));
                }

                result = defvalue;
            }

            return result;
        }
    }
}