// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ExceptionExtensions.cs" company="Tenaris S.A.">
//   Copyright � TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the ExceptionExtensions type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Utility/ExceptionExtensions.cs $
//  $Id: ExceptionExtensions.cs 51126 2011-04-07 19:06:22Z apre2k\t61248 $

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tenaris.Library.Log.Text;

namespace Tenaris.Library.Log.Utility
{
    /// <summary>
    ///     Defines extension methods for <see cref="Exception" />
    /// </summary>
    internal static class ExceptionExtensions
    {
        /// <summary>
        ///     Builds the string formed by all the chain of exceptions up to when innerException returns null.
        /// </summary>
        /// <param name="exception">
        ///     The exception instance to which this method applies.
        /// </param>
        /// <param name="elementSeparator">
        ///     The separator used between element of the chain.
        /// </param>
        /// <returns>
        ///     A string representation of all the stack of exceptions raised.
        /// </returns>
        public static string FullMessage(this Exception exception, string elementSeparator = @" -> ")
        {
            return exception
                .Chain()
                .Aggregate(new StringBuilder(),
                    (b, e) => b.AppendValue(elementSeparator, @"{0}: '{1}'", e.GetType().Name, e.Message))
                .ToString();
        }

        /// <summary>
        ///     Iterates the list of the exceptions formed by the innerException chain.
        /// </summary>
        /// <param name="exception">
        ///     The exception instance to which this method applies.
        /// </param>
        /// <returns>
        ///     An enumerable sequence of exception linked from the given one through its innerException chain.
        /// </returns>
        public static IEnumerable<Exception> Chain(this Exception exception)
        {
            while (exception != null)
            {
                yield return exception;
                exception = exception.InnerException;
            }
        }

        /// <summary>
        ///     Lookups inside the exception's Data dictionary searching for the given key and returns its associated value if
        ///     found,
        ///     or else returns the default value given.
        /// </summary>
        /// <param name="exception">
        ///     The exception instance to which this method applies.
        /// </param>
        /// <param name="key">
        ///     The value's identification key. (Best to use GUIDs for this to avoid ID clashes)
        /// </param>
        /// <param name="defaultValue">
        ///     The default value in case the key is not found.
        /// </param>
        /// <returns>
        ///     Either the value found in the data dictionary or the default value.
        /// </returns>
        /// <exception cref="ArgumentNullException">
        ///     When <paramref name="exception" /> == null.
        /// </exception>
        public static object GetData(this Exception exception, object key, object defaultValue = null)
        {
            if (exception == null)
            {
                throw new ArgumentNullException("exception");
            }

            if (exception.Data.Contains(key))
            {
                defaultValue = exception.Data[key];
            }

            return defaultValue;
        }

        /// <summary>
        ///     Lookups inside the exception's Data dictionary searching for the given key and returns its associated value if
        ///     found,
        ///     or else returns the default value given.
        /// </summary>
        /// <typeparam name="TValueType">
        ///     The type to which the value is converted.
        /// </typeparam>
        /// <param name="exception">
        ///     The exception instance to which this method applies.
        /// </param>
        /// <param name="key">
        ///     The value's identification key. (Best to use GUIDs for this to avoid ID clashes)
        /// </param>
        /// <param name="defaultValue">
        ///     The default value in case the key is not found.
        /// </param>
        /// <returns>
        ///     Either the value found in the data dictionary or the default value.
        /// </returns>
        /// <exception cref="ArgumentNullException">
        ///     When <paramref name="exception" /> == null.
        /// </exception>
        public static TValueType GetData<TValueType>(this Exception exception, object key,
            TValueType defaultValue = default(TValueType))
        {
            object result;

            if ((result = exception.GetData(key)) != null)
            {
                defaultValue = (TValueType) Convert.ChangeType(result, typeof(TValueType));
            }

            return defaultValue;
        }
    }
}