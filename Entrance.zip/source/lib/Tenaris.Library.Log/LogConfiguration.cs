﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Configuration.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Log configuration class.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Log/Configuration.cs $
// $Id: Configuration.cs 57048 2012-01-20 14:47:58Z apre2k\15827 $

namespace Tenaris.Library.Log
{
    using System;
    using System.Configuration;
    using System.IO;
    using System.Security;

    /// <summary>
    /// Log configuration class.
    /// </summary>
    public class LogConfiguration : ConfigurationSection
    {
        private const int DefaultMaxFileSize = 4096;
        private const int DefaultMaxFileCount = 10;
        private const string DefaultMaxAge = "1.00:00:00.000";
        private const bool DefaultSplitLogPerDay = true;
        private const bool DefaultAppend = false;
        private const string DefaultMsgFormat = "{TypeChar} {Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{AppDomainName,30:s-30}:{ThreadName,15:s15}]" +
                                                " [lap={LapFriendlyValue,-7:f2}{LapFriendlyUnit,3}] {AssemblyName,30:s-30} {IdentString} {Message}";
        private const string DefaultLogBaseName = "{ProcessName}";
        private const bool DefaultDumpStack = true;
        private const bool DefaultNoQueue = true;
        private const int DefaultMaxQueueSize = 10000;
        private const int DefaultMaxLogDepth = 0;
        private const string DefaultLogLevel = "Debug";
        private const string DefaultTraceAttributeLogLevel = "Message";
        private const string DefaultIncludeAssembliesRegEx = "";
        private const string DefaultExcludeAssembliesRegEx = "";
        private const string DefaultIncludeFullClasNameRegEx = "";
        private const string DefaultExcludeFullClasNameRegEx = "";
        private const bool DefaultExcludePropertyGetterAndSetter = true;
        private const bool DefaultTraceAttributeLogEnabled = true;
        private const bool DefaultLogAssemblyLoad = true;
        private const int DefaultFlushInterval = 1000;
        private const AdditionalLogDestination DefaultAdditionalLogDestination = AdditionalLogDestination.None;
        private const bool DefaultColorConsoleLog = true;
        private const string DefaultApplicationProfilingType = "Tenaris.Service.Profiling.ProfilingService, Tenaris.Service.Profiling";

        /// <summary>
        /// Initializes a new instance of the <see cref="LogConfiguration"/> class. 
        /// </summary>
        public LogConfiguration()
        {
            MaxFileSize = DefaultMaxFileSize;
            MaxFileCount = DefaultMaxFileCount;
            MaxAge = TimeSpan.Parse(DefaultMaxAge);
            SplitLogPerDay = DefaultSplitLogPerDay;
            Append = DefaultAppend;
            MsgFormat = DefaultMsgFormat;
            LogBaseName = DefaultLogBaseName;
            DumpStack = DefaultDumpStack;
            MaxQueueSize = DefaultMaxQueueSize;
            MaxLogDepth = DefaultMaxLogDepth;
            LogLevel = (LogLevel)Enum.Parse(typeof(LogLevel), DefaultLogLevel, true);
            TraceAttributeLogLevel = (LogLevel)Enum.Parse(typeof(LogLevel), DefaultTraceAttributeLogLevel, true);
            IncludeAssembliesRegEx = DefaultIncludeAssembliesRegEx;
            ExcludeAssembliesRegEx = DefaultExcludeAssembliesRegEx;
            IncludeFullClasNameRegEx = DefaultIncludeFullClasNameRegEx;
            ExcludeFullClasNameRegEx = DefaultExcludeFullClasNameRegEx;
            ExcludePropertyGetterAndSetter = DefaultExcludePropertyGetterAndSetter;
            FlushInterval = DefaultFlushInterval;
            AdditionalLogDestination = DefaultAdditionalLogDestination;
            NoQueue = DefaultNoQueue;
            LogAssemblyLoad = DefaultLogAssemblyLoad;
            ColorConsoleLog = DefaultColorConsoleLog;
            TraceAttributeLogEnabled = DefaultTraceAttributeLogEnabled;
            ApplicationProfilingType = DefaultApplicationProfilingType;
        }

        /// <summary>
        /// Gets or sets the Path where the log file will be placed. Default value is null.
        /// The property returns the current process path if set to null or an empty string.
        /// </summary>
        [ConfigurationProperty(@"path", DefaultValue = null, IsRequired = false)]
        public string Path
        {
            get
            {
                return String.IsNullOrEmpty((string)base[@"path"]) ? GetProcessDirectory() + @"\" : (string)base[@"path"];
            }

            set
            {
                base[@"path"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the Max log file size. If it is exceeded, the log will be rotated. Default value: 2048.
        /// </summary>
        [ConfigurationProperty(@"maxFileSize", DefaultValue = DefaultMaxFileSize, IsRequired = false)]
        public int MaxFileSize
        {
            get
            {
                return (int)base[@"maxFileSize"];
            }

            set
            {
                base[@"maxFileSize"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the Maximum log file count. This will determine how many log files will be kept before deleting. Default value: 10.
        /// </summary>
        [ConfigurationProperty(@"maxFileCount", DefaultValue = DefaultMaxFileCount, IsRequired = false)]
        public int MaxFileCount
        {
            get
            {
                return (int)base[@"maxFileCount"];
            }

            set
            {
                base[@"maxFileCount"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the Max log file age. If a file is older than this threshold, log will be rotated. Default value: 1.00:00:00.000.
        /// </summary>
        [ConfigurationProperty(@"maxAge", DefaultValue = DefaultMaxAge, IsRequired = false)]
        public TimeSpan MaxAge
        {
            get
            {
                return (TimeSpan)base[@"maxAge"];
            }

            set
            {
                base[@"maxAge"] = value;
            }
        }

        /// <summary>
        /// <para>
        /// Gets or sets a value indicating whether the logger will try to append the new log to the last available log file.
        /// </para>
        /// <para>
        /// As always, if the file must be rotated because it is old, or big enough, the new log wont be appended but instead a new file will be created. 
        /// Default value = false.
        /// </para>
        /// </summary>
        [ConfigurationProperty(@"append", DefaultValue = DefaultAppend, IsRequired = false)]
        public bool Append
        {
            get
            {
                return (bool)base[@"append"];
            }

            set
            {
                base[@"append"] = value;
            }
        }

        /// <summary>
        /// <para>
        /// Gets or sets a value indicating whether the logger will change file every new day.
        /// </para>
        /// <para>
        /// As always, if the file must be rotated because day cnahged, the new log wont be appended but instead a new file will be created. 
        /// Default value = false.
        /// </para>
        /// </summary>
        [ConfigurationProperty(@"splitLogPerDay", DefaultValue = DefaultSplitLogPerDay, IsRequired = false)]
        public bool SplitLogPerDay
        {
            get
            {
                return (bool)base[@"splitLogPerDay"];
            }

            set
            {
                base[@"splitLogPerDay"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the Message format to use. It used named placedholders so you can build something like 
        /// "{TypeChar} {Timestamp:yyyy-MM-dd HH:mm} [{AppDomainName,-20}] {AssemblyName,-15} {IdentString} {Message}". 
        /// Default value: TBD.
        /// </summary>
        [ConfigurationProperty(@"msgFormat", DefaultValue = DefaultMsgFormat, IsRequired = false)]
        public string MsgFormat
        {
            get
            {
                return (string)base[@"msgFormat"];
            }

            set
            {
                base[@"msgFormat"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the format to use for building file names. Take into account that this is the base name for the log file, 
        /// so if every message has a different base name, you will get a LOT of files.
        /// </summary>
        [ConfigurationProperty(@"logBaseName", DefaultValue = DefaultLogBaseName, IsRequired = false)]
        public string LogBaseName
        {
            get
            {
                return (string)base[@"logBaseName"];
            }

            set
            {
                base[@"logBaseName"] = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether every time an unhandle exception is logged at the exit of a function, 
        /// the full call stack will be logged. Default value: true.
        /// </summary>
        [ConfigurationProperty(@"dumpStack", DefaultValue = DefaultDumpStack, IsRequired = false)]
        public bool DumpStack
        {
            get
            {
                return (bool)base[@"dumpStack"];
            }

            set
            {
                base[@"dumpStack"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the max length of the buffer queue (in message number). Default value: 10000.
        /// </summary>
        [ConfigurationProperty(@"maxQueueSize", DefaultValue = DefaultMaxQueueSize, IsRequired = false)]
        public int MaxQueueSize
        {
            get
            {
                return (int)base[@"maxQueueSize"];
            }

            set
            {
                base[@"maxQueueSize"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the max depth above which no msg will be logged.
        /// </summary>
        [ConfigurationProperty(@"maxLogDepth", DefaultValue = DefaultMaxLogDepth, IsRequired = false)]
        public int MaxLogDepth
        {
            get
            {
                return (int)base[@"maxLogDepth"];
            }

            set
            {
                base[@"maxLogDepth"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the trace level. All messages with log level higher than this will be excluded.
        /// </summary>
        [ConfigurationProperty(@"logLevel", DefaultValue = DefaultLogLevel, IsRequired = false)]
        public LogLevel LogLevel
        {
            get
            {
                return (LogLevel)base[@"logLevel"];
            }

            set
            {
                base[@"logLevel"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the trace attribute level. All messages with log level higher than this will be excluded.
        /// </summary>
        [ConfigurationProperty(@"traceAttributeLogLevel", DefaultValue = DefaultTraceAttributeLogLevel, IsRequired = false)]
        public LogLevel TraceAttributeLogLevel
        {
            get
            {
                return (LogLevel)base[@"traceAttributeLogLevel"];
            }

            set
            {
                base[@"traceAttributeLogLevel"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the regex used to filter trace messages by the originating assembly. If this rule matchs it will be included no matter 
        /// if the Exclude rule matches too.
        /// </summary>
        [ConfigurationProperty(@"includeAssembliesRegEx", DefaultValue = DefaultIncludeAssembliesRegEx, IsRequired = false)]
        public string IncludeAssembliesRegEx
        {
            get
            {
                return (string)base[@"includeAssembliesRegEx"];
            }

            set
            {
                base[@"includeAssembliesRegEx"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the regex used to filter trace messages by the originating assembly. 
        /// If this rule matchs it will be included no matter if the Exclude rule matches too.
        /// </summary>
        [ConfigurationProperty(@"excludeAssembliesRegEx", DefaultValue = DefaultExcludeAssembliesRegEx, IsRequired = false)]
        public string ExcludeAssembliesRegEx
        {
            get
            {
                return (string)base[@"excludeAssembliesRegEx"];
            }

            set
            {
                base[@"excludeAssembliesRegEx"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the regex used to filter trace messages by the originating source class. Allows filtering by namespace+typename.
        /// If this rule matchs it will be included no matter if the Exclude rule matches too.
        /// </summary>
        [ConfigurationProperty(@"includeFullClasNameRegEx", DefaultValue = DefaultIncludeFullClasNameRegEx, IsRequired = false)]
        public string IncludeFullClasNameRegEx
        {
            get { return (string)base[@"includeFullClasNameRegEx"]; }
            set { base[@"includeFullClasNameRegEx"] = value; }
        }

        /// <summary>
        /// Gets or sets the regex used to filter trace messages by the originating source class. Allows filtering by namespace+typename. 
        /// If this rule matchs it will be excluded if the Exclude rule does not match.
        /// </summary>
        [ConfigurationProperty(@"excludeFullClasNameRegEx", DefaultValue = DefaultExcludeFullClasNameRegEx, IsRequired = false)]
        public string ExcludeFullClasNameRegEx
        {
            get
            {
                return (string)base[@"excludeFullClasNameRegEx"];
            }

            set
            {
                base[@"excludeFullClasNameRegEx"] = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether to exclude props getters and setters.
        /// </summary>
        [ConfigurationProperty(@"excludePropertyGetterAndSetter", DefaultValue = DefaultExcludePropertyGetterAndSetter, IsRequired = false)]
        public bool ExcludePropertyGetterAndSetter
        {
            get
            {
                return (bool)base[@"excludePropertyGetterAndSetter"];
            }

            set
            {
                base[@"excludePropertyGetterAndSetter"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the flush interval for the writer. Default value is 1000ms.
        /// </summary>
        [ConfigurationProperty(@"flushInterval", DefaultValue = DefaultFlushInterval, IsRequired = false)]
        public int FlushInterval
        {
            get
            {
                return (int)base[@"flushInterval"];
            }

            set
            {
                base[@"flushInterval"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the trace attribute log enable. Disabling the trace attribute log still updates the internal stack.
        /// </summary>
        [ConfigurationProperty(@"traceAttributeLogEnabled", DefaultValue = DefaultTraceAttributeLogEnabled, IsRequired = false)]
        public bool TraceAttributeLogEnabled
        {
            get
            {
                return (bool)base[@"traceAttributeLogEnabled"];
            }

            set
            {
                base[@"traceAttributeLogEnabled"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the additional log destinations. If not specified, no additional log destinations will be used.
        /// </summary>
        [ConfigurationProperty(@"additionalLogDestination", DefaultValue = DefaultAdditionalLogDestination, IsRequired = false)]
        public AdditionalLogDestination AdditionalLogDestination
        {
            get
            {
                return (AdditionalLogDestination)base[@"additionalLogDestination"];
            }

            set
            {
                base[@"additionalLogDestination"] = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the log write is enqueued or not.
        /// </summary>
        [ConfigurationProperty(@"noQueue", DefaultValue = DefaultNoQueue, IsRequired = false)]
        public bool NoQueue
        {
            get
            {
                return (bool)base[@"noQueue"];
            }

            set
            {
                base[@"noQueue"] = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether to log assembly load events
        /// </summary>
        [ConfigurationProperty(@"logAssemblyLoad", DefaultValue = DefaultLogAssemblyLoad, IsRequired = false)]
        public bool LogAssemblyLoad
        {
            get
            {
                return (bool)base[@"logAssemblyLoad"];
            }

            set
            {
                base[@"logAssemblyLoad"] = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether color messages sent to console
        /// </summary>
        [ConfigurationProperty(@"colorConsoleLog", DefaultValue = DefaultColorConsoleLog, IsRequired = false)]
        public bool ColorConsoleLog
        {
            get
            {
                return (bool)base[@"colorConsoleLog"];
            }

            set
            {
                base[@"colorConsoleLog"] = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether color messages sent to console
        /// </summary>
        [ConfigurationProperty(@"applicationProfilingType", DefaultValue = DefaultApplicationProfilingType, IsRequired = false)]
        public string ApplicationProfilingType
        {
            get
            {
                return (string)base[@"applicationProfilingType"];
            }

            set
            {
                base[@"applicationProfilingType"] = value;
            }
        }

        /// <summary>
        /// Returns the current process full directory path.
        /// </summary>
        /// <returns></returns>
        [SecuritySafeCritical]
        internal static string GetProcessDirectory()
        {
            var fi = new FileInfo(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName);
            return fi.DirectoryName;
        }
    }
}
