﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Message.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Log level.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Log/Message.cs $
// $Id: Message.cs 54311 2011-08-26 22:15:13Z apre2k\15827 $

namespace Tenaris.Library.Log
{
    using System;
    using System.Diagnostics;
    using System.Threading;

    using Engineering;
    using System.Reflection;
    using System.Security;

    /// <summary>
    /// Log level.
    /// </summary>
    [Serializable]
    public enum LogLevel
    {
        /// <summary>
        /// A most detailed message.
        /// </summary>
        Debug,

        /// <summary>
        /// A general, informative, message.
        /// </summary>
        Message,

        /// <summary>
        /// A warning that does not prevents the process from executing but may impact
        /// in functionality.
        /// </summary>
        Warning,

        /// <summary>
        /// A critic error.
        /// </summary>
        Error,
    }

    /// <summary>
    /// Log type enumeration.
    /// </summary>
    [Serializable]
    public enum LogType
    {
        /// <summary>
        /// Represents an enter event.
        /// </summary>
        Enter,

        /// <summary>
        /// Represents a manually generated message.
        /// </summary>
        Message,

        /// <summary>
        /// Represents a leave event.
        /// </summary>
        Leave
    }

    /// <summary>
    /// A LogMessage with all available data for logging.
    /// </summary>
    [Serializable]
    public struct LogMessage
    {
        private static readonly TimeHumanReadableValue TimeConverter = new TimeHumanReadableValue();

        /// <summary>
        /// Gets or sets the full class name that originated the message.
        /// </summary>
        public string FullClassName { get; set; }

        /// <summary>
        /// Gets or sets timestamp at which the message was generated.
        /// </summary>
        public DateTime Timestamp { get; set; }

        /// <summary>
        /// Gets or sets log level of the message.
        /// </summary>
        public LogLevel Level { get; set; }

        /// <summary>
        /// Gets or sets actual message.
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets the process name that originated the message.
        /// </summary>
        public string ProcessName { get; set; }

        /// <summary>
        /// Gets or sets the process name that originated the message.
        /// </summary>
        public int ProcessId { get; set; }

        /// <summary>
        /// Gets or sets the application domain that originated the message.
        /// </summary>
        public string AppDomainName { get; set; }

        /// <summary>
        /// Gets or sets the class name that originated the message.
        /// </summary>
        public string ClassName { get; set; }

        /// <summary>
        /// Gets or sets the method name that originated the message.
        /// </summary>
        public string MethodName { get; set; }

        /// <summary>
        /// Gets or sets the thread name from which the message was created.
        /// </summary>
        public string ThreadName { get; set; }

        /// <summary>
        /// Gets or sets the thread id from which the message was created.
        /// </summary>
        public int ThreadId { get; set; }

        /// <summary>
        /// Gets an identation string that represents de depth of the call stack and direction of the message.
        /// </summary>
        public string IdentString
        {
            get
            {
                return '|' + new string(' ', Depth) + TypeChar;
            }
        }

        /// <summary>
        /// Gets a char indicating the type of message (> for enter, - for message, ! for warning, @ for error, &lt; for leave).
        /// </summary>
        public char TypeChar
        {
            get
            {
                char typeChar;

                switch (Type)
                {
                    case LogType.Enter:
                        typeChar = Constants.EnterChar;
                        break;

                    case LogType.Message:
                        switch (Level)
                        {
                            case LogLevel.Debug:
                                typeChar = Constants.InfoChar;
                                break;
                            case LogLevel.Message:
                                typeChar = Constants.InfoChar;
                                break;
                            case LogLevel.Warning:
                                typeChar = Constants.WarnChar;
                                break;
                            case LogLevel.Error:
                                typeChar = Constants.ErrorChar;
                                break;
                            default:
                                typeChar = '?';
                                break;
                        }
                        break;

                    case LogType.Leave:
                        typeChar = Constants.LeaveChar;
                        break;

                    default:
                        typeChar = '?';
                        break;
                }

                return typeChar;
            }
        }

        /// <summary>
        /// Gets or sets the depth in the call stack.
        /// </summary>
        public int Depth { get; set; }

        /// <summary>
        /// Gets or sets time since last message or enter.
        /// </summary>
        public double Lap { get; set; }

        /// <summary>
        /// Gets the most significant digits (unit).
        /// </summary>
        public string LapFriendlyUnit
        {
            get
            {
                return TimeConverter.ToHumanReadable(Lap).Unit;
            }
        }

        /// <summary>
        /// Gets the most significant digits (value).
        /// </summary>
        public double LapFriendlyValue
        {
            get
            {
                return TimeConverter.ToHumanReadable(Lap).Value;
            }
        }

        /// <summary>
        /// Gets or sets the assembly name where the class that generated the message is.
        /// </summary>
        public string AssemblyName { get; set; }

        /// <summary>
        /// Gets or sets the log type. Enter, Message or Leave.
        /// </summary>
        public LogType Type { get; set; }

        /// <summary>
        /// Force message log
        /// </summary>
        public bool ForceLog { get; set; }

        [SecuritySafeCritical]
        internal static LogMessage SignOffMessage()
        {
            var workerType = typeof(Worker);
            var currentDomain = AppDomain.CurrentDomain;
            var assembly = Assembly.GetAssembly(workerType);
            var currentProcess = Process.GetCurrentProcess();
            var currentThread = Thread.CurrentThread;

            var msg = new LogMessage
            {
                AppDomainName = currentDomain.FriendlyName,
                AssemblyName = assembly.GetName().Name,
                Type = LogType.Message,
                ClassName = workerType.Name,
                Depth = 1,
                ForceLog = true,
                FullClassName = workerType.FullName,
                Lap = 0,
                Level = LogLevel.Debug,
                Message = "Trace signing off. If you see this message, then no log lines were lost.",
                MethodName = "N/A",
                ProcessId = currentProcess.Id,
                ProcessName = currentProcess.MainModule.ModuleName,
                ThreadId = currentThread.ManagedThreadId,
                ThreadName = currentThread.Name ?? currentThread.ManagedThreadId.ToString(),
                Timestamp = DateTime.Now
            };

            return msg;
        }
    }
}