﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Writer.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the WriterConfig type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Log/Writer.cs $
// $Id: Writer.cs 57334 2012-02-02 12:50:45Z apre2k\15827 $

namespace Tenaris.Library.Log
{
  using System;
  using System.Runtime.InteropServices;
  using System.Diagnostics;
  using System.IO;
  using System.Security;

  /// <summary>
  /// LogWriter class configuration
  /// </summary>
  [SecurityCritical]
  internal struct WriterConfig
  {
    [DllImport("kernel32.dll")]
    static extern IntPtr GetConsoleWindow();

    private string path;
    private string baseName;
    private AdditionalLogDestination additionalLogDestination;

    public bool Append { get; set; }

    public TimeSpan MaxAge { get; set; }

    public bool SplitLogPerDay { get; set; }

    /// <summary>
    /// Gets the maximum file count
    /// </summary>
    public int MaxFileCount { get; set; }

    /// <summary>
    /// Gets the maximum file size (in kilobytes)
    /// </summary>
    public int MaxSize { get; set; }

    /// <summary>
    /// Gets/sets the Log path
    /// </summary>
    public string Path
    {
      get { return path; }
      set { path = EnvironmentHelper.ExpandEnvironmentVariables(value); }
    }
    /// <summary>
    /// Gets the log basename
    /// </summary>
    public string BaseName
    {
      get { return baseName; }
      set { baseName = EnvironmentHelper.ExpandEnvironmentVariables(value); }
    }

    /// <summary>
    /// Set to true to flush in every write
    /// </summary>
    public bool AutoFlush { get; set; }

    /// <summary>
    /// Gets the log flush interval
    /// </summary>
    public int FlushInterval { get; set; }

    /// <summary>
    /// Gets the log level
    /// </summary>
    public LogLevel LogLevel { get; set; }

    /// <summary>
    /// Gets/sets additiona log destinations
    /// </summary>
    public AdditionalLogDestination AdditionalLogDestination
    {
      get { return additionalLogDestination; }
      set
      {
        if (value == AdditionalLogDestination.Console && GetConsoleWindow() == IntPtr.Zero) return;
        additionalLogDestination = value;
      }
    }

    /// <summary>
    /// Returns true if the Console log destination is enabled
    /// </summary>
    public bool LogToConsole
    {
      get { return (AdditionalLogDestination & AdditionalLogDestination.Console) != 0; }
    }

    /// <summary>
    /// Returns true if messages sent to console are colored
    /// </summary>
    public bool ColorConsoleLog { get; set; }
  }

  /// <summary>
  /// LogWriter class
  /// </summary>
  [SecurityCritical]
  internal class LogWriter
  {
    private readonly WriterConfig config;
    private StreamWriter writer;
    private DateTime fileCreationTime = DateTime.MinValue;

    /// <summary>
    /// Initializes a new instance of LogWriter class
    /// </summary>
    /// <param name="config"></param>
    public LogWriter(WriterConfig config)
    {
      this.config = config;
      ActiveFileName = Path.Combine(this.config.Path, String.Format(@"{0}.log", this.config.BaseName));
      InitializeStream();
    }

    public string ActiveFileName { get; private set; }

    /// <summary>
    /// Writes a new log line
    /// </summary>
    /// <param name="msg"></param>
    public void WriteLine(string msg)
    {
      Check();
      writer.WriteLine(msg);
    }

    /// <summary>
    /// Flushes the log writer
    /// </summary>
    public void Flush()
    {
      writer.Flush();
    }

    /// <summary>
    /// Closes the log writer
    /// </summary>
    public void ReleaseWriter()
    {
      try
      {
        if (writer != null)
        {
          writer.Flush();
          writer.Close();
          writer.Dispose();
        }
      }
      finally
      {
        writer = null;
      }
    }

    private bool NeedsCycling
    {
      get
      {
        if (writer == null)
        {
          return true;
        }

        // Checks if the file is big enough so cycling is needed.
        if (writer.BaseStream.Length >= config.MaxSize * 1024) { return true; }

        // Checks if the file is old enough so cycling is needed.
        if (fileCreationTime + config.MaxAge < DateTime.Now) { return true; }

        // check if the current day is different from the file creation day
        if (config.SplitLogPerDay & (fileCreationTime.Day != DateTime.Now.Day)) { return true; }

        return false;
      }
    }

    private void Check()
    {
      if (NeedsCycling)
      {
        InitializeNewFile();
        if (writer == null)
        {
          InitializeLastFile();
        }
        else
        {
          writer.WriteLine(Constants.TraceFileBegin, DateTime.Now);
        }
      }
    }

    private void InitializeStream()
    {
      if (!Directory.Exists(config.Path))
      {
        Directory.CreateDirectory(config.Path);
      }

      if (config.Append)
      {
        InitializeLastFile();
      }

      if (writer == null)
      {
        InitializeNewFile();
      }

      if (writer != null)
        writer.WriteLine(Constants.TraceFileBegin, DateTime.Now);
    }

    private void InitializeNewFile()
    {
      ReleaseWriter();

      if (File.Exists(ActiveFileName))
      {
        FileInfo fi = new FileInfo(ActiveFileName);
        var fileNameWithoutExt = String.Format(@"{0}-{1}", config.BaseName, fi.CreationTime.ToString(Constants.FileDateFormat));
        var files = Directory.GetFiles(config.Path, fileNameWithoutExt + "*.log");
        var archiveFileName = Path.Combine(config.Path, String.Format(@"{0}.{1}.log", fileNameWithoutExt, files.Length));

        try
        {
          File.Move(ActiveFileName, archiveFileName);
        }
        catch { }
      }

      try
      {
        File.Create(ActiveFileName).Dispose();
        fileCreationTime = DateTime.Now;
        File.SetCreationTime(ActiveFileName, fileCreationTime);
        writer = File.AppendText(ActiveFileName);
        writer.AutoFlush = config.AutoFlush;
      }
      catch { }

      RemoveOldFiles();
    }

    private void InitializeLastFile()
    {
      ReleaseWriter();

      if (File.Exists(ActiveFileName))
      {
        writer = File.AppendText(ActiveFileName);
        writer.AutoFlush = config.AutoFlush;
        var fileInfo = new FileInfo(ActiveFileName);
        fileInfo.Refresh();
        fileCreationTime = fileInfo.CreationTime;
      }
    }

    private void RemoveOldFiles()
    {
      if (config.MaxFileCount > 0)
      {
        var files = Directory.GetFiles(config.Path, config.BaseName + "-*");
        if (files.Length > config.MaxFileCount)
        {
          Array.Sort(files, StringComparer.InvariantCultureIgnoreCase);
          for (var i = 0; i < files.Length - config.MaxFileCount; i++)
          {
            try
            {
              File.Delete(files[i]);
            }
            catch (Exception e)
            {
              String errorMessage = String.Format(@"[LOGGER] Could not delete old file ""{0}"" because ""{1}""", files[i], e.Message);
              Debug.WriteLine(errorMessage);
              Console.WriteLine(errorMessage);
            }
          }
        }
      }
    }
  }
}