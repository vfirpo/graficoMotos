﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="NoTraceAttribute.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the NoTraceAttribute type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Log/NoTraceAttribute.cs $
//  $Id: NoTraceAttribute.cs 50155 2011-03-01 18:19:58Z apre2k\t61248 $

namespace Tenaris.Library.Log
{
    using System;

    /// <summary>
    /// Use this attribute to signal that a specific target on which this attribute is applied should not be hooked by the [Trace] aspect.
    /// </summary>
    [AttributeUsage(AttributeTargets.All, Inherited = false)]
    public sealed class NoTraceAttribute : Attribute
    {
    }
}