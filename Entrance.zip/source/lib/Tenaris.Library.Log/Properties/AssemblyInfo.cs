﻿// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Properties/AssemblyInfo.cs $
// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="Tenaris S.A.">
//   Tenaris S.A. 2009
// </copyright>
// <summary>
//   AssemblyInfo.cs
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $Id: AssemblyInfo.cs 30048 2010-03-09 15:26:58Z apre2k\t61248 $

using System.Runtime.InteropServices;
using System.Security;

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("2e7b877c-7a01-4a0a-bf61-a9175f5a8e2e")]
[assembly: AllowPartiallyTrustedCallers]
[assembly: SecurityRules(SecurityRuleSet.Level2, SkipVerificationInFullTrust = true)]
