using System.Reflection;
[assembly: AssemblyCompany("Tenaris S.A.")]
[assembly: AssemblyTrademark("Tenaris S.A.")]
[assembly: AssemblyCopyright("Copyright� Tenaris S.A. ${build_year}")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyTitle("Tenaris.Library.Log")]
[assembly: AssemblyDescription("${bitbucket_metadata}")]
[assembly: AssemblyProduct("${bitbucket_project}/${bitbucket_repository}")]

[assembly: AssemblyVersion("4.${git_version_major}.0.0")]
[assembly: AssemblyFileVersion("${git_version_major}.${git_version_minor}.${git_commit_sequential_hi}.${git_commit_sequential_lo}")]
[assembly: AssemblyInformationalVersion("4.${git_version_major}.${git_version_minor}${git_prerelease_branch}${git_buildmetadata}")]
