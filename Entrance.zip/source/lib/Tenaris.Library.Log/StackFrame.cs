﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="StackFrame.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the StackFrame type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Log/StackFrame.cs $
// $Id: StackFrame.cs 54311 2011-08-26 22:15:13Z apre2k\15827 $

namespace Tenaris.Library.Log
{
    using System;

    /// <summary>
    /// Represents a frame in the "Enter's" stack.
    /// </summary>
    [Serializable]
    public class StackFrame
    {
        /// <summary>
        /// Gets or sets TimeStamp.
        /// </summary>
        public DateTime TimeStamp { get; set; }

        /// <summary>
        /// Gets or sets Initial.
        /// </summary>
        public long Initial { get; set; }

        /// <summary>
        /// Gets or sets Current.
        /// </summary>
        public long Current { get; set; }

        /// <summary>
        /// Gets or sets AssemblyName.
        /// </summary>
        public string AssemblyName { get; set; }

        /// <summary>
        /// Gets or sets MethodName.
        /// </summary>
        public string MethodName { get; set; }

        /// <summary>
        /// Gets or sets ThreadId.
        /// </summary>
        public int ThreadId { get; set; }

        /// <summary>
        /// Gets or sets ClassName.
        /// </summary>
        public string ClassName { get; set; }

        /// <summary>
        /// Gets or sets ThreadName.
        /// </summary>
        public string ThreadName { get; set; }

        /// <summary>
        /// Gets or sets AppDomainName.
        /// </summary>
        public string AppDomainName { get; set; }

        /// <summary>
        /// Gets or sets ProcessName.
        /// </summary>
        public string ProcessName { get; set; }

        /// <summary>
        /// Gets or sets ProcessName.
        /// </summary>
        public int ProcessId { get; set; }

        /// <summary>
        /// Gets or sets FullClassName.
        /// </summary>
        public string FullClassName { get; set; }
    }
}