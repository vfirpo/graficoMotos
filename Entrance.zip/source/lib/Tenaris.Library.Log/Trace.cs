﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Trace.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Static trace tool for logging.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Log/Trace.cs $
// $Id: Trace.cs 55557 2011-11-01 13:32:18Z apre2k\15827 $

using Tenaris.Library.Log.FrameworkInternal.Utility.Annotations;

namespace Tenaris.Library.Log
{
  using System;
  using System.Collections.Generic;
  using System.Configuration;
  using System.Diagnostics;
  using System.Globalization;
  using System.Reflection;
  using System.Security;
  using System.Security.Permissions;
  using System.Text;
  using System.Threading;

  using Framework;
  using Utility;
  using Utility.AppDomain;
  using Properties;

  /// <summary>
  /// Static trace tool for logging.
  /// </summary>
  [AppDomainName(UseDefaultDomain = true)]
  [SecuritySafeCritical]
  public class Trace : CrossDomainSingleton<Trace>
  {
    private readonly Worker worker;
    private readonly Dictionary<int, Stack<StackFrame>> stackTraces = new Dictionary<int, Stack<StackFrame>>();
    private static readonly Process Process;
    private readonly LogConfiguration logConfiguration;
    private static bool dumpStack;

    [SecurityCritical]
    private Trace()
    {
      try
      {
        try
        {
          logConfiguration = ConfigurationManager.GetSection(@"log") as LogConfiguration ?? new LogConfiguration();
        }
        catch (Exception e)
        {
          logConfiguration = new LogConfiguration();
          System.Diagnostics.Trace.WriteLine(String.Format(@"Trace() failed with msg '{0}'", e));
        }

        var writerConfig = new WriterConfig
        {
          Append = logConfiguration.Append,
          MaxAge = logConfiguration.MaxAge,
          SplitLogPerDay = logConfiguration.SplitLogPerDay,
          MaxFileCount = logConfiguration.MaxFileCount,
          AutoFlush = logConfiguration.NoQueue,
          MaxSize = logConfiguration.MaxFileSize,
          Path = logConfiguration.Path,
          BaseName = Resources.TraceUndefinedFileBaseName,
          FlushInterval = logConfiguration.FlushInterval,
          LogLevel = logConfiguration.LogLevel,
          AdditionalLogDestination = logConfiguration.AdditionalLogDestination,
          ColorConsoleLog = logConfiguration.ColorConsoleLog
        };

        worker = new Worker(writerConfig, logConfiguration);
        dumpStack = logConfiguration.DumpStack;
        worker.Start();

        if (logConfiguration.LogAssemblyLoad)
        {
          AppDomain.CurrentDomain.AssemblyLoad += OnAssemblyLoad;
        }

        StartApplicationProfiling();

      }
      catch (Exception e)
      {
        System.Diagnostics.Trace.WriteLine(String.Format(@"Trace() failed with msg '{0}'", e));
      }
    }

    private void StartApplicationProfiling()
    {
      if (!string.IsNullOrWhiteSpace(logConfiguration.ApplicationProfilingType))
      {
        Trace.Debug("Application Profiling Service configured, trying to activate {0}", logConfiguration.ApplicationProfilingType);
        try
        {
          Type applicationProfilingType = Type.GetType(logConfiguration.ApplicationProfilingType);

          if (applicationProfilingType == null)
          {
            Trace.Warning("Application Profiling Service not loaded. Could not get type for type name {0}", logConfiguration.ApplicationProfilingType);
          }
          else
          {
            Trace.Debug("Application Profiling Service type loaded.");
            PropertyInfo instanceProperty = applicationProfilingType.GetProperty("Instance", BindingFlags.Public | BindingFlags.Static);
            if (instanceProperty == null)
            {
              Trace.Warning("Application Profiling Service not loaded. Could not get property static 'Instance' for type name {0}", logConfiguration.ApplicationProfilingType);
            }
            else
            {
              instanceProperty.GetValue(null, null);
            }
          }
        }
        catch (Exception ex)
        {
          Trace.Warning("Application Profiling Service not loaded. Exception message: {0}", ex.Message);
        }
      }
    }

    [SecurityCritical]
    [PermissionSet(SecurityAction.Assert, Unrestricted = true)]
    static Trace()
    {
      Process = Process.GetCurrentProcess();
    }

    /// <summary>
    /// Current log level
    /// </summary>
    public static LogLevel LogLevel
    {
      get
      {
        return Instance.worker.LogLevel;
      }
      set
      {
        Instance.worker.LogLevel = value;
      }
    }

    /// <summary>
    /// Returns a value indicating if trace attribute is enabled.
    /// </summary>
    public static bool TraceAttributeEnabled
    {
      get
      {
        return Instance.logConfiguration.TraceAttributeLogEnabled;
      }
    }

    /// <summary>
    /// Logs a message with level "Debug".
    /// </summary>
    /// <param name="message"> Message to log.</param>
    /// <param name="args"> Args to format the message.</param>
    [StringFormatMethod("message")]
    public static void Debug(string message, params object[] args)
    {
      try
      {
        DoLogMessage(LogLevel.Debug, false, false, message, args);
      }
      catch (Exception e)
      {
        System.Diagnostics.Trace.WriteLine(String.Format(@"Debug() failed with msg '{0}'", e));
      }
    }

    /// <summary>
    /// Logs a message with level "Debug".
    /// </summary>
    /// <param name="message"> Message to log.</param>
    /// <param name="args"> Args to format the message.</param>
    [StringFormatMethod("message")]
    public static void ForceDebug(string message, params object[] args)
    {
      try
      {
        DoLogMessage(LogLevel.Debug, true, false, message, args);
      }
      catch (Exception e)
      {
        System.Diagnostics.Trace.WriteLine(String.Format(@"Debug() failed with msg '{0}'", e));
      }
    }

    /// <summary>
    /// Logs a message with level "Message".
    /// </summary>
    /// <param name="message"> Message to log.</param>
    /// <param name="args"> Args to format the message.</param>
    [StringFormatMethod("message")]
    public static void Message(string message, params object[] args)
    {
      try
      {
        DoLogMessage(LogLevel.Message, false, false, message, args);
      }
      catch (Exception e)
      {
        System.Diagnostics.Trace.WriteLine(String.Format(@"Message() Failed with msg '{0}'", e));
      }
    }

    /// <summary>
    /// Logs a message with level "Message".
    /// </summary>
    /// <param name="message"> Message to log.</param>
    /// <param name="args"> Args to format the message.</param>
    [StringFormatMethod("message")]
    public static void ForceMessage(string message, params object[] args)
    {
      try
      {
        DoLogMessage(LogLevel.Message, true, false, message, args);
      }
      catch (Exception e)
      {
        System.Diagnostics.Trace.WriteLine(String.Format(@"Message() Failed with msg '{0}'", e));
      }
    }

    /// <summary>
    /// Logs a message with level "Warning".
    /// </summary>
    /// <param name="message"> Message to log.</param>
    /// <param name="args"> Args to format the message.</param>
    [StringFormatMethod("message")]
    public static void Warning(string message, params object[] args)
    {
      try
      {
        DoLogMessage(LogLevel.Warning, false, false, message, args);
      }
      catch (Exception e)
      {
        System.Diagnostics.Trace.WriteLine(String.Format(@"Warning() failed with msg '{0}'", e));
      }
    }

    /// <summary>
    /// Logs a message with level "Warning".
    /// </summary>
    /// <param name="message"> Message to log.</param>
    /// <param name="args"> Args to format the message.</param>
    [StringFormatMethod("message")]
    public static void ForceWarning(string message, params object[] args)
    {
      try
      {
        DoLogMessage(LogLevel.Warning, true, false, message, args);
      }
      catch (Exception e)
      {
        System.Diagnostics.Trace.WriteLine(String.Format(@"Warning() failed with msg '{0}'", e));
      }
    }

    /// <summary>
    /// Logs a message with level "Error".
    /// </summary>
    /// <param name="message"> Message to log.</param>
    /// <param name="args"> Args to format the message.</param>
    [StringFormatMethod("message")]
    public static void Error(string message, params object[] args)
    {
      try
      {
        DoLogMessage(LogLevel.Error, false, false, message, args);
      }
      catch (Exception e)
      {
        System.Diagnostics.Trace.WriteLine(String.Format(@"Error() failed with msg '{0}'", e));
      }
    }

    /// <summary>
    /// Logs a message with level "Error". It will log the stack trace of the exception given.
    /// </summary>
    /// <param name="exception"> The exception used to extract the trace dump.</param>
    /// <param name="message"> Message to log.</param>
    /// <param name="args"> Args to format the message.</param>
    [StringFormatMethod("message")]
    public static void Exception(Exception exception, string message, params object[] args)
    {
      try
      {
        var msg = new StringBuilder(String.Format(CultureInfo.CurrentCulture, message, args));
        if (exception != null)
        {
          msg.Append(String.Format("\r\nException message: {0}", exception.Message));
          msg.Append(Constants.StackTraceBegin);
          msg.Append(exception.StackTrace);
          msg.Append(Constants.StackTraceEnd);
        }

        DoLogMessage(LogLevel.Error, false, false, msg.ToString());
      }
      catch (Exception e)
      {
        System.Diagnostics.Trace.WriteLine(String.Format(@"Error() failed with msg '{0}'", e));
      }
    }

    /// <summary>
    /// Logs a message with level "Error". It will log the stack trace of the exception given.
    /// </summary>
    /// <param name="exception"> The exception used to extract the trace dump.</param>
    /// <param name="dumpCallStack">Whether to dump the call stack or not.</param>
    public static void Exception(Exception exception, bool dumpCallStack = true)
    {
      try
      {
        Exception(
            dumpCallStack ? exception : null,
            dumpCallStack ? Constants.ExceptionFormat : Constants.ExceptionFormatNoStack,
            exception.FullMessage());
      }
      catch (Exception e)
      {
        System.Diagnostics.Trace.WriteLine(String.Format(@"Error() failed with msg '{0}'", e));
      }
    }

    /// <summary>
    /// Logs a message with variable level.
    /// </summary>      
    /// <param name="level"> Message log level</param>
    /// <param name="message"> Message to log.</param>
    /// <param name="args"> Args to format the message.</param>
    public static void LogMessage(LogLevel level, string message, params object[] args)
    {
      try
      {
        DoLogMessage(level, false, false, message, args);
      }
      catch (Exception e)
      {
        System.Diagnostics.Trace.WriteLine(String.Format(@"LogMessage() Failed with msg '{0}'", e));
      }
    }

    /// <summary>
    /// Logs a message with variable level.
    /// </summary>
    /// <param name="level"> Message log level</param>
    /// <param name="message"> Message to log.</param>
    /// <param name="args"> Args to format the message.</param>
    public static void ForceLogMessage(LogLevel level, string message, params object[] args)
    {
      try
      {
        DoLogMessage(level, true, false, message, args);
      }
      catch (Exception e)
      {
        System.Diagnostics.Trace.WriteLine(String.Format(@"LogMessage() Failed with msg '{0}'", e));
      }
    }

    internal static void Enter(string className, string fullClassName, string methodName, string assemblyName, string message)
    {
      Enter(Instance.logConfiguration.TraceAttributeLogLevel, className, fullClassName, methodName, assemblyName, message);
    }

    internal static void Enter(LogLevel level, string className, string fullClassName, string methodName, string assemblyName, string message)
    {
      try
      {
        var now = Stopwatch.GetTimestamp();

        // ReSharper disable ConstantNullCoalescingCondition
        var frame = new StackFrame
        {
          Initial = now,
          Current = now,
          AssemblyName = assemblyName,
          ClassName = className,
          FullClassName = fullClassName,
          MethodName = methodName,
          TimeStamp = DateTime.Now,
          ThreadId = Thread.CurrentThread.ManagedThreadId,
          ThreadName = Thread.CurrentThread.Name ?? Thread.CurrentThread.ManagedThreadId.ToString(),
          AppDomainName = AppDomain.CurrentDomain.FriendlyName,
          ProcessName = Process.MainModule.ModuleName,
          ProcessId = Process.Id
        };

        // ReSharper restore ConstantNullCoalescingCondition
        var elapsedTime = GetElapsedTime(Instance.PeekStack(frame.ThreadId).Current);
        Instance.PushStack(frame.ThreadId, frame);

        var msg = new LogMessage
        {
          AppDomainName = frame.AppDomainName,
          AssemblyName = frame.AssemblyName,
          ClassName = frame.ClassName,
          Depth = Instance.StackCount(frame.ThreadId),
          Lap = elapsedTime,
          Level = level,
          MethodName = frame.MethodName,
          Message = message,
          ThreadId = frame.ThreadId,
          ThreadName = frame.ThreadName,
          Timestamp = DateTime.Now,
          Type = LogType.Enter,
          FullClassName = frame.FullClassName,
          ProcessName = frame.ProcessName,
          ProcessId = frame.ProcessId
        };

        Instance.EnqueueMessage(msg);
      }
      catch (Exception e)
      {
        System.Diagnostics.Trace.WriteLine(String.Format(@"Error() failed with msg '{0}'", e));
      }
    }

    internal static void Leave(string message)
    {
      Leave(Instance.logConfiguration.TraceAttributeLogLevel, message);
    }

    internal static void Leave(LogLevel level, string message)
    {
      try
      {
        DoLogMessage(level, false, true, message);
      }
      catch (Exception e)
      {
        System.Diagnostics.Trace.WriteLine(String.Format(@"Leave() failed with msg '{0}'", e));
      }
    }

    internal static void Error(string message, Exception e, bool showStackFrame = true)
    {
      try
      {
        if (dumpStack && showStackFrame)
        {
          Exception(e, message, e.FullMessage());
        }
        else
        {
          Error(message, e.FullMessage());
        }
      }
      catch (Exception ex)
      {
        System.Diagnostics.Trace.WriteLine(String.Format(@"Error() failed with msg '{0}'", ex));
      }
    }

    private static double GetElapsedTime(long lastValue)
    {
      var perfCounter = Stopwatch.GetTimestamp();
      var delta = perfCounter - lastValue;
      if (delta < 0)
      {
        return Double.NaN;
      }

      return 1000 * 1000 * delta / (double)Stopwatch.Frequency;
    }

    [StringFormatMethod("message")]
    [SecuritySafeCritical]
    [PermissionSet(SecurityAction.Assert, Unrestricted = true)]
    private static void DoLogMessage(LogLevel level, bool forceLog, bool isLeaving, string message, params object[] args)
    {
      var threadId = Thread.CurrentThread.ManagedThreadId;

      var depth = Instance.StackCount(threadId);
      var frame = isLeaving ? Instance.PopStack(threadId) : Instance.PeekStack(threadId);

      double elapsedTime;

      if (isLeaving)
      {
        elapsedTime = GetElapsedTime(frame.Initial);
      }
      else
      {
        elapsedTime = GetElapsedTime(frame.Current);
        frame.Current = Stopwatch.GetTimestamp();
      }

      var msg = new LogMessage
      {
        AppDomainName = frame.AppDomainName,
        AssemblyName = frame.AssemblyName,
        ClassName = frame.ClassName,
        Depth = depth,
        ForceLog = forceLog,
        Lap = elapsedTime,
        Level = level,
        MethodName = frame.MethodName,
        ThreadId = frame.ThreadId,
        ThreadName = frame.ThreadName ?? @"<No Name>",
        Timestamp = DateTime.Now,
        Type = isLeaving ? LogType.Leave : LogType.Message,
        FullClassName = frame.FullClassName,
        ProcessName = frame.ProcessName,
        ProcessId = frame.ProcessId
      };

      try
      {
        msg.Message = string.Format(CultureInfo.CurrentCulture, message, args);
      }
      catch (Exception)
      {
        var plain = true;
        if (message.Contains("{"))
        {
          try
          {
            msg.Message = string.Format(CultureInfo.CurrentCulture, message.Replace("{", "{{").Replace("}", "}}"), args);
            plain = false;
          }
          catch { }
        }

        if (plain) msg.Message = "cannot format: " + message;
      }

      Instance.EnqueueMessage(msg);
    }

    private void EnqueueMessage(LogMessage msg)
    {
      if (worker != null)
      {
        if (logConfiguration.NoQueue)
        {
          worker.WriteMessageNoQueue(msg);
        }
        else
        {
          worker.Enqueue(msg);
        }
      }
    }

    private Stack<StackFrame> GetStackTrace(int threadId)
    {
      Stack<StackFrame> stackTrace;
      var now = Stopwatch.GetTimestamp();
      if (!stackTraces.TryGetValue(threadId, out stackTrace))
      {
        stackTrace = new Stack<StackFrame>();

        // ReSharper disable ConstantNullCoalescingCondition
        stackTrace.Push(new StackFrame
        {
          AppDomainName = AppDomain.CurrentDomain.FriendlyName,
          AssemblyName = Assembly.GetExecutingAssembly().GetName().Name,
          ClassName = typeof(Trace).Name,
          Current = now,
          FullClassName = typeof(Trace).FullName,
          Initial = now,
          MethodName = string.Empty,
          ProcessName = Process.MainModule.ModuleName,
          ProcessId = Process.Id,
          ThreadId = Thread.CurrentThread.ManagedThreadId,
          ThreadName = Thread.CurrentThread.Name ?? Thread.CurrentThread.ManagedThreadId.ToString(),
          TimeStamp = DateTime.Now,
        });

        // ReSharper enable ConstantNullCoalescingCondition
        stackTraces.Add(threadId, stackTrace);
        Message(@"NEW THREAD");
      }

      return stackTrace;
    }

    private void OnAssemblyLoad(object sender, AssemblyLoadEventArgs args)
    {
      try
      {
        Message(
            "[ASSEMBLY_LOADED] FullName={0} - Location={1}", args.LoadedAssembly.FullName, args.LoadedAssembly.IsDynamic ? "N/A" : args.LoadedAssembly.Location);
      }
      catch
      {
        System.Diagnostics.Trace.WriteLine("[TRACER] Failed to handle AssemblyLoad event to log the assembly being loaded.");
      }
    }

    private StackFrame PeekStack(int threadId)
    {
      return GetStackTrace(threadId).Peek();
    }

    private StackFrame PopStack(int threadId)
    {
      return GetStackTrace(threadId).Pop();
    }

    private void PushStack(int threadId, StackFrame frame)
    {
      GetStackTrace(threadId).Push(frame);
    }

    private int StackCount(int threadId)
    {
      return GetStackTrace(threadId).Count;
    }
  }
}