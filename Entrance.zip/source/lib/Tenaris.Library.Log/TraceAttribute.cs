﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="TraceAttribute.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   A AOP attribute to trace the execution of a class/method. Add this to a class or method in order to
//   automatically log enters and leaves (both success or errors).
//   The level of log is pretty high, including methods parameters (both names and values), and results.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
// $URL: https://svn.apre.siderca.ot/source/library/system/sandbox/2.xx-testing/source/sharedlib/System/Log/TraceAttribute.cs $
// $Id: TraceAttribute.cs 50322 2011-03-08 13:57:58Z apre2k\t61248 $

namespace Tenaris.Library.Log
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Globalization;
    using System.Linq;
    using System.Reflection;
    using System.Runtime.Remoting;
    using System.Security;

    using PostSharp.Aspects;
    using PostSharp.Extensibility;

    using Utility;

    /// <summary>
    /// A AOP attribute to trace the execution of a class/method. Add this to a class or method in order to
    /// automatically log enters and leaves (both success or errors).
    /// The level of log is pretty high, including methods parameters (both names and values), and results.
    /// </summary>
    [Serializable]
    [DebuggerNonUserCode]
    [DebuggerStepThrough]
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Property | AttributeTargets.Method | AttributeTargets.Assembly |
                      AttributeTargets.Struct | AttributeTargets.Interface | AttributeTargets.Constructor | AttributeTargets.Event)]
    [MulticastAttributeUsage(MulticastTargets.Method | MulticastTargets.InstanceConstructor, AllowMultiple = false, AllowExternalAssemblies = false)]
    [SecuritySafeCritical]
    public sealed class TraceAttribute : OnMethodBoundaryAspect
    {
        private string methodName;
        private string declaringType;
        private string assemblyName;
        private string enterFormat;
        private string leaveFormat;
        private string fatalFormat;
        private string fullDeclaringType;
        private bool fullExceptionStack = true;

        /// <summary>
        /// Gets or sets a value indicating whether to log full exception stack traces when the method raises an exception.
        /// </summary>
        public bool FullExceptionStack
        {
            get
            {
                return fullExceptionStack;
            }

            set
            {
                fullExceptionStack = value;
            }
        }

        /// <summary>
        /// AOP Internal method. DO NOT CALL IT.
        /// </summary>
        /// <param name="method">
        /// The method to inspect at compile time.
        /// </param>
        /// <param name="aspectInfo">
        /// The aspect Info.
        /// </param>
        public override void CompileTimeInitialize(MethodBase method, AspectInfo aspectInfo)
        {
            try
            {
                methodName = GetMethodName(method);
                declaringType = GetTypeName(method.DeclaringType, false);
                fullDeclaringType = GetTypeName(method.DeclaringType, true);
                assemblyName = method.DeclaringType.Assembly.GetName().Name;

                leaveFormat = string.Format(@"{0}.{1}({{0}})", declaringType, methodName);
                fatalFormat = string.Format(@"The execution of {0}.{1}() finished unexpectdly. The error message is '{{0}}'", declaringType, methodName);

                enterFormat = string.Format(@"{0}.{1}(", declaringType, methodName);
                foreach (var param in method.GetParameters())
                {
                    if (param.IsRetval)
                    {
                        continue;
                    }

                    enterFormat += string.Format(@"{0} = {{{1}}}, ", param.Name, param.Position);
                }

                enterFormat = enterFormat.TrimEnd(',');
                enterFormat += @")";
            }
            catch (Exception exception)
            {
                throw new InvalidOperationException(string.Format(@"Coulnd't initialize the instance of the TraceAttribute for method: '{0}.{1}'", method.DeclaringType.Name, method.Name), exception);
            }
        }

        /// <summary>
        /// AOP Internal method. DO NOT CALL IT.
        /// </summary>
        /// <param name="method">
        /// The method to inspect at compile time.
        /// </param>
        /// <returns>
        /// A value used to indicate if the aspect can be applied to the given method.
        /// </returns>
        public override bool CompileTimeValidate(MethodBase method)
        {
            if (method.DeclaringType != null && IsDefined(method.DeclaringType.Assembly, typeof(NoTraceAttribute)))
            {
                return false;
            }

            if (IsDefined(method, typeof(NoTraceAttribute), true))
            {
                return false;
            }

            if (method.IsVirtual && method.IsPublic && (method.Name == @"ToString"))
            {
                return false;
            }

            if (method.Name.StartsWith(@"set_") || method.Name.StartsWith(@"get_"))
            {
                return false;
            }

            if (method.IsSpecialName)
            {
                return false;
            }

            return base.CompileTimeValidate(method);
        }

        /// <summary>
        /// AOP Internal method. DO NOT CALL IT.
        /// </summary>
        /// <param name="ev">
        /// The event Args.
        /// </param>
        public override void OnEntry(MethodExecutionArgs ev)
        {
            try
            {
                if (!Trace.TraceAttributeEnabled) { return; }
                var arguments = ev.Arguments.ToArray();

                Trace.Enter(
                  LogLevel.Message,
                  declaringType,
                  fullDeclaringType,
                  methodName,
                  assemblyName,
                  arguments != null ? FormatArguments(enterFormat, arguments) : enterFormat);
            }
            catch (Exception e)
            {
                System.Diagnostics.Trace.WriteLine(String.Format(@"OnEntry() Failed with msg '{0}'", e));
            }
        }

        /// <summary>
        /// AOP Internal method. DO NOT CALL IT.
        /// </summary>
        /// <param name="ev">
        /// The event Args.
        /// </param>
        public override void OnSuccess(MethodExecutionArgs ev)
        {
            try
            {
                if (!Trace.TraceAttributeEnabled) { return; }
                Trace.Leave(LogLevel.Message, FormatArguments(leaveFormat, ev.ReturnValue));
            }
            catch (Exception e)
            {
                System.Diagnostics.Trace.WriteLine(String.Format(@"OnSuccess() Failed with msg '{0}'", e));
            }
        }

        /// <summary>
        /// AOP Internal method. DO NOT CALL IT.
        /// </summary>
        /// <param name="ev">
        /// The event Args.
        /// </param>
        public override void OnException(MethodExecutionArgs ev)
        {
            try
            {
                if (!Trace.TraceAttributeEnabled) { return; }
                if (fullExceptionStack)
                {
                    Trace.Error(fatalFormat, ev.Exception);
                }

                Trace.Leave(LogLevel.Message, FormatArguments(leaveFormat, string.Format(@"{0}{1}>", @"<thrown ", ev.Exception.FullMessage())));
            }
            catch (Exception e)
            {
                System.Diagnostics.Trace.WriteLine(String.Format(@"OnException() Failed with msg '{0}'", e));
            }
        }

        private static string FormatArguments(string format, params object[] args)
        {
            try
            {
                return String.Format(CultureInfo.InvariantCulture, format, ConvertArguments(args));
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex);
                return string.Format(@"<failed: {0}>", ex.FullMessage());
            }
        }

        private static string GetTypeName(Type type, bool full)
        {
            var name = full ? type.FullName : type.Name;
            return type.IsGenericType ? GetGenericTypeName(name, type.GetGenericArguments()) : name;
        }

        private static string GetGenericTypeName(string typeName, IEnumerable<Type> args)
        {
            var name = typeName.Split('`')[0];
            var result = args.Aggregate(
              String.Empty,
              (current, arg) => current + string.Format(@"{0}, ", GetTypeName(arg, false)));

            result = result.Remove(result.Length - 2, 2);
            return String.Format(@"{0}<{1}>", name, result);
        }

        private static string GetMethodName(MethodBase method)
        {
            return method.IsGenericMethod ? GetGenericTypeName(method.Name, method.GetGenericArguments()) : method.Name;
        }

        private static string[] ConvertArguments(IList<object> args)
        {
            if (args == null)
            {
                throw new ArgumentNullException("args");
            }

            var result = new string[args.Count];
            for (var index = 0; index < args.Count; index++)
            {
                result[index] = ConvertObject(args[index]);
            }

            return result;
        }

        private static string ConvertObject(object item)
        {
            try
            {
                if (RemotingServices.IsTransparentProxy(item))
                {
                    return String.Format(@"<remote_object={0}>", RemotingServices.GetObjectUri(item as MarshalByRefObject));
                }

                return item != null ? item.ToString() : @"<null>";
            }
            catch (Exception e)
            {
                System.Diagnostics.Trace.WriteLine(e);
                return string.Format(@"<failed: {0}>", e.FullMessage());
            }
        }
    }
}
