﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Worker.cs" company="Tenaris S.A.">
//   Copyright © TenarisSIDERCA APRE 2009-2010
// </copyright>
// <summary>
//   Defines the Worker type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Tenaris.Library.Log
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;
    using System.Runtime.ExceptionServices;
    using System.Security;
    using System.Text.RegularExpressions;
    using System.Threading;

    using FormatProviders;
    using Text;

    /// <summary>
    /// Log worker class
    /// </summary>
    [SecurityCritical]
    internal class Worker
    {
        private readonly BlockingCollection<LogMessage> msgQueue;
        private readonly Dictionary<string, LogWriter> writers = new Dictionary<string, LogWriter>();
        private readonly string msgFormat;
        private readonly string logBaseName;
        private readonly int maxLogDepth;
        private readonly Regex includeAssembliesRegEx;
        private readonly Regex excludeAssembliesRegEx;
        private LogLevel logLevel;
        private readonly bool excludePropertyGetterAndSetter;
        private readonly Regex excludeFullClasNameRegEx;
        private readonly Regex includeFullClasNameRegEx;
        private readonly WriterConfig writerConfig;
        private readonly Thread worker;
        private bool isRunning;
        private readonly object writersLock = new object();

        /// <summary>
        /// Initializes a new instance of <see cref="Worker"/> class
        /// </summary>
        /// <param name="writerConfig"></param>
        /// <param name="config"></param>
        public Worker(WriterConfig writerConfig, LogConfiguration config)
        {
            msgFormat = config.MsgFormat;
            logBaseName = config.LogBaseName;
            maxLogDepth = config.MaxLogDepth;
            includeAssembliesRegEx = !string.IsNullOrEmpty(config.IncludeAssembliesRegEx) ? new Regex(config.IncludeAssembliesRegEx) : null;
            excludeAssembliesRegEx = !string.IsNullOrEmpty(config.ExcludeAssembliesRegEx) ? new Regex(config.ExcludeAssembliesRegEx) : null;
            includeFullClasNameRegEx = !string.IsNullOrEmpty(config.IncludeFullClasNameRegEx) ? new Regex(config.IncludeFullClasNameRegEx) : null;
            excludeFullClasNameRegEx = !string.IsNullOrEmpty(config.ExcludeFullClasNameRegEx) ? new Regex(config.ExcludeFullClasNameRegEx) : null;
            excludePropertyGetterAndSetter = config.ExcludePropertyGetterAndSetter;
            logLevel = config.LogLevel;
            msgQueue = new BlockingCollection<LogMessage>(new ConcurrentQueue<LogMessage>(), config.MaxQueueSize);

            this.writerConfig = writerConfig;

            AppDomain.CurrentDomain.ProcessExit += OnMainThreadExit;
            AppDomain.CurrentDomain.UnhandledException += OnUnhandledException;

            if (!config.NoQueue)
                worker = new Thread(Run) { IsBackground = true, Name = "TRACE"};
        }

        /// <summary>
        /// Gets/sets the current log level
        /// </summary>
        public LogLevel LogLevel
        {
            get { return logLevel; }
            set { logLevel = value; }
        }

        /// <summary>
        /// Enqueues a message to be logged.
        /// </summary>
        /// <param name="msg">Message to log.</param>
        public void Enqueue(LogMessage msg)
        {
            msgQueue.Add(msg);
        }

        /// <summary>
        /// Set the working thread in running state.
        /// </summary>
        public void Start()
        {
            if (!isRunning)
            {
                isRunning = true;
                if (worker != null)
                    worker.Start();
            }
        }

        /// <summary>
        /// Set the working thread in stop state.
        /// </summary>
        public void Stop()
        {
            if (isRunning)
            {
                // This will unlock the working thread.
                isRunning = false;
                if (worker != null)
                    worker.Join();
            }
        }

        /// <summary>
        /// Checks if the specifed message can be logged.
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private bool NeedsToBeLogged(LogMessage message)
        {
            // if the log is forced, return true
            if (message.ForceLog)
            {
                return true;
            }

            // First of all, the most trivial an less consuming checks...
            if (maxLogDepth > 0 && message.Depth > maxLogDepth)
            {
                return false;
            }

            if (message.Level < logLevel)
            {
                return false;
            }

            if (excludePropertyGetterAndSetter && (message.MethodName.StartsWith(@"get_") || message.MethodName.StartsWith(@"set_")))
            {
                return false;
            }

            if (excludeAssembliesRegEx != null && excludeAssembliesRegEx.IsMatch(message.AssemblyName))
            {
                return false;
            }

            if (includeAssembliesRegEx != null && !includeAssembliesRegEx.IsMatch(message.AssemblyName))
            {
                return false;
            }

            if (excludeFullClasNameRegEx != null && excludeFullClasNameRegEx.IsMatch(message.FullClassName))
            {
                return false;
            }

            if (includeFullClasNameRegEx != null && !includeFullClasNameRegEx.IsMatch(message.FullClassName))
            {
                return false;
            }

            return true;
        }

        private void Run()
        {
            const int minFlushInterval = 500;
            DateTime lastFlush = DateTime.Now;
            int flushInterval = writerConfig.FlushInterval <= 0 ?
                                 -1 :
                                 writerConfig.FlushInterval < minFlushInterval ? minFlushInterval : writerConfig.FlushInterval;

            while (isRunning)
            {
                try
                {
                    do
                    {
                        LogMessage msg;

                        if (msgQueue.TryTake(out msg, 100) && NeedsToBeLogged(msg))
                        {
                            WriteMessage(msg);
                        }
                    } while (msgQueue.Count > 0);

                    if (flushInterval <= 0 || DateTime.Now - lastFlush > TimeSpan.FromMilliseconds(flushInterval))
                    {
                        Flush();
                        lastFlush = DateTime.Now;
                    }
                }
                catch (Exception e)
                {
                    String errorMessage = String.Format(@"[LOGGER] Exception with msg ""{0}"" was unhandled in the thread loop, will keep trying.", e.Message);
                    Debug.WriteLine(errorMessage);
                    Console.WriteLine(errorMessage);
                }
            }

            WriteMessage(LogMessage.SignOffMessage());
            ReleaseWriters();
        }

        private void Flush()
        {
            foreach (var writer in writers.Values)
            {
                writer.Flush();
            }
        }

        private void ReleaseWriters()
        {
            foreach (var writer in writers.Values)
            {
                writer.ReleaseWriter();
            }
        }

        public void WriteMessageNoQueue(LogMessage msg)
        {
            lock (writersLock)
            {
                if (NeedsToBeLogged(msg))
                {
                    WriteMessage(msg);
                }
            }
        }

        private void WriteMessage(LogMessage msg)
        {
            var writer = GetWriterForMessage(msg);
            var message = msgFormat.Inject(StandardFormatProvider.Instance, msg, true);
            message = Regex.Replace(message, Environment.NewLine, Environment.NewLine + "+");

            writer.WriteLine(message);

            if (writerConfig.LogToConsole)
            {
                if (writerConfig.ColorConsoleLog)
                    SetConsoleColor(msg.Level);
                Console.WriteLine(message);
            }
        }

        private void SetConsoleColor(LogLevel level)
        {
            switch (level)
            {
                case LogLevel.Debug:
                case LogLevel.Message:
                    Console.ForegroundColor = ConsoleColor.Gray;
                    break;
                case LogLevel.Warning:
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    break;
                case LogLevel.Error:
                    Console.ForegroundColor = ConsoleColor.Red;
                    break;
                default:
                    throw new ArgumentOutOfRangeException("level", level, null);
            }
        }

        private LogWriter GetWriterForMessage(LogMessage msg)
        {
            var baseName = logBaseName.Inject(msg);
            var fileDir = writerConfig.Path.Inject(msg);
            var filePath = Path.Combine(fileDir, baseName);

            LogWriter writer;

            if (!writers.TryGetValue(filePath, out writer))
            {
                var config = writerConfig;
                config.Path = fileDir;
                config.BaseName = baseName;
                writer = new LogWriter(config);
                writers.Add(filePath, writer);
            }

            return writer;
        }

        private void OnMainThreadExit(object sender, EventArgs eventArgs)
        {
            Stop();
        }

        [SecurityCritical]
        [HandleProcessCorruptedStateExceptions]
        private void OnUnhandledException(object sender, UnhandledExceptionEventArgs eventArgs)
        {
            var exception = eventArgs.ExceptionObject as Exception;
            if (exception != null)
            {
                Trace.Exception(exception, "The process is terminating due to an unhandled exception.");
            }

            Stop();
        }
    }
}